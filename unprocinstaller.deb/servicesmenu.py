import sys
import subprocess
from PyQt5.QtWidgets import (
    QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QScrollArea
)
from PyQt5.QtGui import QPixmap, QFont, QFontDatabase
from PyQt5.QtCore import QTimer, Qt, QEvent

class SvcWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.load_font()

        self.setWindowTitle('Unprotected Cyberscript')
        self.setFixedSize(1366, 768)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self.show_menu)
        self.switch_timer.setSingleShot(True)
        self.switch_timer.start(0)

    def load_font(self):
        font_path = "fonts/Milibus Bold.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            print(f"Font loaded: {font_family}")
        else:
            print("Failed to load font. Please check the font path and file.")

    def show_menu(self):
        menu_widget = QWidget(self)

        background_label = QLabel(menu_widget)
        background_label.setPixmap(QPixmap("backgrounds/menuservices.png"))
        background_label.setScaledContents(True)
        background_label.setGeometry(0, 0, self.width(), self.height())

        scroll_area = QScrollArea(menu_widget)
        scroll_area.setWidgetResizable(True)
        scroll_area.setGeometry(50, 175, 500, 500)
        scroll_area.setStyleSheet("""
            QScrollArea {
                background: transparent;
            }
            QScrollArea > QWidget > QWidget {
                background: transparent;
            }
            QScrollBar:vertical {
                background: transparent;
                width: 15px;
            }
            QScrollBar::handle:vertical {
                background: transparent;
                min-height: 20px;
                border-radius: 7px;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                background: none;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }
        """)

        button_container = QWidget()
        button_container.setStyleSheet("background: transparent;")

        vbox_layout = QVBoxLayout(button_container)
        vbox_layout.setSpacing(20)
        vbox_layout.setContentsMargins(0, 0, 0, 35)
        vbox_layout.setAlignment(Qt.AlignTop)

        button_names = [
            "Configure Mandatory Services",
            "Configure Apache2",
            "Configure AppArmor",
            "Configure AuditD",
            "Configure Bind9",
            "Configure MariaDB",
            "Configure MySQL",
            "Configure Nginx",
            "Configure Nullmailer",
            "Configure OpenVPN",
            "Configure PHP",
            "Configure ProFTPD",
            "Configure PureFTPD"
            "Configure PostgreSQL",
            "Configure Samba",
            "Configure SSH",
            "Configure VSFTPD",
            "Back to Main Menu",
        ]

        for name in button_names:
            button = QPushButton(name)
            button.clicked.connect(lambda checked, name=name: self.on_button_click(name))
            button.setFont(QFont("Milibus", 16))
            button.setStyleSheet("""
                QPushButton {
                    text-align: left;
                    color: gray;
                    background: none;
                    border: none;
                    padding-left: 50px;
                }
                QPushButton:hover {
                    color: #f0a001;
                }
            """)
            button.installEventFilter(self)
            vbox_layout.addWidget(button)

        scroll_area.setWidget(button_container)
        self.setCentralWidget(menu_widget)

    def eventFilter(self, source, event):
        if event.type() == QEvent.Enter and isinstance(source, QPushButton):
            source.setStyleSheet("""
                QPushButton {
                    text-align: left;
                    color: gray;
                    background: none;
                    border: 3px solid #a7823b;
                    padding-left: 50px;
                    padding-top: 10px;
                    padding-bottom: 10px;
                }
                QPushButton:hover {
                    color: #f0a001;
                }
            """)
        elif event.type() == QEvent.Leave and isinstance(source, QPushButton):
            source.setStyleSheet("""
                QPushButton {
                    text-align: left;
                    color: gray;
                    background: none;
                    border: none;
                    padding-left: 45px;
                }
                QPushButton:hover {
                    color: #f0a001;
                }
            """)
        return super().eventFilter(source, event)

    def on_button_click(self, button_name):
        script_mapping = {
            "Configure Mandatory Services": "services/svcman.sh",
            "Configure Apache2": "services/svcapache2.sh",
            "Configure AppArmor": "services/svcapparmor.sh",
            "Configure AuditD": "services/svcauditd.sh",
            "Configure Bind9": "services/svcbind9.sh",
            "Configure MariaDB": "services/svcmariadb.sh",
            "Configure MySQL": "services/svcmysql.sh",
            "Configure Nginx": "services/svcnginx.sh",
            "Configure Nullmailer": "services/svcnullmailer.sh",
            "Configure OpenVPN": "services/svcopenvpn.sh",
            "Configure PHP": "services/svcphp.sh",
            "Configure ProFTPD": "services/svcproftpd.sh",
            "Configure PureFTPD": "services/svcpureftpd.sh",
            "Configure PostgreSQL": "services/svcpostgresql.sh",
            "Configure Samba": "services/svcsamba.sh",
            "Configure SSH": "services/svcssh.sh",
            "Configure VSFTPD": "services/svcvsftpd.sh",
            "Back to Main Menu": "back.sh"
        }
        script_name = script_mapping.get(button_name)
        if script_name:
            self.run_script(script_name)

    def run_script(self, script_name):
        try:
            subprocess.run(["./" + script_name], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.warning(self, "Error", f"Failed to run {script_name}: {e}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {e}")

def load_svc_content(main_window):
    svc_window = SvcWindow()
    main_window.setCentralWidget(svc_window)