#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configSSH () {
    echo "${GREEN}[+] Configurating services SSH '${REPLY}'${RESET}"
    # Unique config file each time
    sudo cp /etc/ssh/sshd_config backup/services/sshd_config_`date +%s`.bak

    # sshd_config 
    echo "Protocol 2" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    # echo "Port 4369"  | sudo tee -a /etc/ssh/sshd_config > /dev/null # Idk about this one chief
    
    sudo ufw allow ssh # depends on the port setting, make sure to read README about SSH ports

    echo "PermitRootLogin no"      | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitEmptyPasswords no" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "LoginGraceTime 20"       | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "X11Forwarding no"         | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "X11UseLocalhost yes"      | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "AllowTcpForwarding no"    | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "AllowAgentForwarding no"  | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "UsePAM yes"                   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "UseLogin no"                  | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PasswordAuthentication no"    | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "HostBasedAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "RhostsRSAAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PubkeyAuthentication yes"     | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "IgnoreRhosts yes"             | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "StrictModes yes"              | sudo tee -a /etc/ssh/sshd_config > /dev/null

    # echo "UsePrivilegeSeparation yes"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PrintLastLog no"              | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitUserEnvironment no"     | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "SyslogFacility AUTH"          | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "LogLevel VERBOSE" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "MaxAuthTries 3"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "MaxStartups 2"    | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "ChallengeResponseAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "KerberosAuthentication no"            | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "GSSAPIAuthentication no"              | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "UseDNS no"        | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitTunnel no"  | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "ClientAliveInterval 300"  | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "ClientAliveCountMax 0"    | sudo tee -a /etc/ssh/sshd_config > /dev/null

    #---- Liams changes, edit it iyw im not very good at it
    echo "IgnoreUserKnownHosts yes" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "Compression no" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    

    echo 'MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256' | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "Banner /etc/issue.net" | sudo tee -a /etc/ssh/sshd_config > /dev/null

    # New welcome banner
    echo "Alexander Boris de Pfeffel Johnson Nicholas \"Harperina\" Owenson is gay" | sudo tee /etc/issue.net > /dev/null

    GOODSYNTAX=$(sudo sshd -t)
    if [[ ! -z $GOODSYNTAX ]]
    then
        echo "${RED}Sshd config has some faults, please check script or ${BOLD}/etc/ssh/sshd_config${RESET}"
        read -rp ""
    fi

    # File permissions
    sudo chown root /etc/ssh/sshd_config
    sudo chgrp root /etc/ssh/sshd_config
    sudo chmod 600 /etc/ssh/sshd_config

    sudo service ssh restart
}
configSSH