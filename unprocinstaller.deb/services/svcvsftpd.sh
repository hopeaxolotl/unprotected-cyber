#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configVSFTPD () {
    echo "${GREEN}[+] Configurating services VSFTPD '${REPLY}'${RESET}"
    # Unique config file each time
    local config_file="/etc/vsftpd.conf"
    if [[ ! -f $config_file ]]
    then 
        config_file="/etc/vsftpd/vsftpd.conf"
    fi 

    sudo cp $config_file backup/services/vsftpd_conf_`date +%s`.bak

    sudo ufw allow ftp 
    sudo ufw allow 20

    # vsftpd.conf

    # Jail users to home directory (user will need a home dir to exist)
    echo "chroot_local_user=YES"                        | sudo tee $config_file > /dev/null
    echo "chroot_list_enable=YES"                       | sudo tee -a $config_file > /dev/null
    echo "chroot_list_file=/etc/vsftpd.chroot_list"     | sudo tee -a $config_file > /dev/null
    echo "allow_writeable_chroot=YES"                   | sudo tee -a $config_file > /dev/null # Only enable if you want files to be editable

    # Allow or deny users
    echo "userlist_enable=YES"                  | sudo tee -a $config_file > /dev/null
    echo "userlist_file=/etc/vsftpd.userlist"   | sudo tee -a $config_file > /dev/null
    echo "userlist_deny=NO"                     | sudo tee -a $config_file > /dev/null

    # General config
    echo "anonymous_enable=NO"          | sudo tee -a $config_file > /dev/null # disable  anonymous login
    echo "local_enable=YES"             | sudo tee -a $config_file > /dev/null # permit local logins
    echo "write_enable=YES"             | sudo tee -a $config_file > /dev/null # enable FTP commands which change the filesystem
    echo "local_umask=022"              | sudo tee -a $config_file > /dev/null # value of umask for file creation for local users
    echo "dirmessage_enable=YES"        | sudo tee -a $config_file > /dev/null # enable showing of messages when users first enter a new directory
    echo "xferlog_enable=YES"           | sudo tee -a $config_file > /dev/null # a log file will be maintained detailing uploads and downloads
    echo "connect_from_port_20=YES"     | sudo tee -a $config_file > /dev/null # use port 20 (ftp-data) on the server machine for PORT style connections
    echo "xferlog_std_format=YES"       | sudo tee -a $config_file > /dev/null # keep standard log file format
    echo "listen=NO"                    | sudo tee -a $config_file > /dev/null # prevent vsftpd from running in standalone mode
    echo "listen_ipv6=YES"              | sudo tee -a $config_file > /dev/null # vsftpd will listen on an IPv6 socket instead of an IPv4 one
    echo "pam_service_name=vsftpd"      | sudo tee -a $config_file > /dev/null # name of the PAM service vsftpd will use
    echo "userlist_enable=YES"          | sudo tee -a $config_file > /dev/null # enable vsftpd to load a list of usernames
    echo "tcp_wrappers=YES"             | sudo tee -a $config_file > /dev/null # turn on tcp wrappers
    echo "ssl_enable=YES"		        | sudo tee -a $config_file > /dev/null # Enables logging in with SSL, risky (but is scored)

    echo "ascii_upload_enable=NO"   | sudo tee -a $config_file > /dev/null 
    echo "ascii_download_enable=NO" | sudo tee -a $config_file > /dev/null 

    sudo service vsftpd restart 
}
configVSFTPD