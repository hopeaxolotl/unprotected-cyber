#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configNULLMAILER () {
    echo "${GREEN}[+] Configurating services NULLMAILER '${REPLY}'${RESET}"
    sudo apt install nullmailer aide
    sudo aide --init

    echo "/sbin/auditctl p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/auditd p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/ausearch p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/aureport p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/autrace p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/audispd p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/augenrules p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null

    echo "SILENTREPORTS=no" | sudo tee -a /etc/default/aide > /dev/null
}
configNULLMAILER