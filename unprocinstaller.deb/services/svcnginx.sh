#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configNGINX () {
    echo "${GREEN}[+] Configurating services NGINX '${REPLY}'${RESET}"
    #config nginx wall hahaahahfdsgjl;kf
    echo "return 301 https://$server_name$request_uri;" | sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "limit_conn addr 1;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_req zone=one;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_req_zone $binary_remote_addr zone=one:10m rate=30r/m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_conn_zone $binary_remote_addr zone=addr:10m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "add_header Set-Cookie \"Path=/; HttpOnly; Secure\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Frame-Options \"DENY\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-XSS-Protection \"1; mode=block\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Content-Type-Options: \"nosniff\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Robots-Tag none;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Content-Security-Policy \"default-src 'self';\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Referrer-Policy: \"strict-origin-when-cross-origin\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Content-Type: \"text/html; charset=UTF-8\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Access-Control-Allow-Origin: \"https://MyWebsiteDomain.com\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Opener-Policy: \"same-origin\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Resource-Policy: \"same-site\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Embedder-Policy: \"require-corp\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "server_tokens off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "etag off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    #SSL - Super Shitty Lines
    echo "ssl_prefer_server_ciphers on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_protocols TLSv1.2 TLSv1.3;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_session_timeout 5m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_session_cache shared:SSL:10m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_certificate /etc/ssl/certs/nginx-selfsigned.crt;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_certificate_key /etc/ssl/private/nginx-selfsigned.key;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_dhparam /etc/ssl/certs/dhparam.pem;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    sudo mkdir /etc/ssl/private
    sudo chmod 700 /etc/ssl/private
    sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/nginx-selfsigned.key -out /etc/ssl/certs/nginx-selfsigned.crt
    sudo openssl dhparam -out /etc/ssl/certs/dhparam.pem 2048

    echo "client_body_buffer_size  1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "client_header_buffer_size 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "client_max_body_size 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "large_client_header_buffers 2 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "gzip off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "sendfile on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "tcp_nopush off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "tcp_nodelay on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "keepalive_timeout 65;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "types_hash_max_size 2048;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "access_log /var/log/access.log combined;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "error_log /var/log/warn.log warn;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    sudo service nginx restart && sleep 3 && sudo service nginx status

}
configNGINX