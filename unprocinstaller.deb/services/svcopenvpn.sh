#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configOPENVPN () {
    echo "${GREEN}[+] Configurating services OPENVPN '${REPLY}'${RESET}"
    wget https://git.io/vpn -O openvpn-install.sh
    sudo chmod 700 openvpn-install.sh
    sudo ./openvpn-install.sh

    echo "tls-crypt ta.key 0" | sudo tee -a /etc/openvpn/server/server.conf
    echo "user nobody" | sudo tee -a /etc/openvpn/server/server.conf
    echo "group nobody" | sudo tee -a /etc/openvpn/server/server.conf
    echo "persist-key" | sudo tee -a /etc/openvpn/server/server.conf
    echo "persist-tun" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "cipher AES-256-CBC" | sudo tee -a /etc/openvpn/server/server.conf
    echo "ncp-disable" | sudo tee -a /etc/openvpn/server/server.conf
    echo "6543" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "opt-verify" | sudo tee -a /etc/openvpn/server/server.conf
    echo "keepalive 10 60" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "sudo vi /etc/sysctl.d/" | sudo tee -a /etc/openvpn/server/server.conf
    echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "plugin /usr/share/openvpn/plugin/lib/openvpn-auth-pam.so /etc/pam.d/login" | sudo tee -a /etc/openvpn/server/server.conf
    echo "auth-gen-token 43200" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "dh none" | sudo tee -a /etc/openvpn/server/server.conf
    echo "ecdh-curve secp384r1" | sudo tee -a /etc/openvpn/server/server.conf
    echo "tls-server" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "auth SHA512" | sudo tee -a /etc/openvpn/server/server.conf
    echo "max-clients 12" | sudo tee -a /etc/openvpn/server/server.conf
    
    service openvpn restart
}
configOPENVPN