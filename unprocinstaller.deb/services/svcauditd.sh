#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configAUDITD () {
   echo "${GREEN}[+] Configurating services AUDITD '${REPLY}'${RESET}"
    echo "--loginuid-immutable" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "-b 1024" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "-e 2" | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "write_logs = yes" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_file = /var/log/audit/audit.log" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_group = root" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_format = ENRICHED"  | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "admin_space_left = 50" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "admin_space_left_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "space_left_action = email" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "action_mail_acct = root" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "space_left = 250000" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "disk_full_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "disk_error_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "local_events = yes" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "max_log_file_action = rotate" | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "
	# First rule - delete all
	-D
	#Ensure events that modify date and time information are collected
	-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
	-a always,exit -F arch=b64 -S clock_settime -k time-change
	-a always,exit -F arch=b32 -S clock_settime -k time-change
	-w /etc/localtime -p wa -k time-change
	#Ensure events that modify user/group information are collected
	-w /etc/group -p wa -k identity
	-w /etc/passwd -p wa -k identity
	-w /etc/gshadow -p wa -k identity
	-w /etc/shadow -p wa -k identity
	-w /etc/security/opasswd -p wa -k identity
	#Ensure events that modify the system's network environment are collected
	-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale
	-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale
	-w /etc/issue -p wa -k system-locale
	-w /etc/issue.net -p wa -k system-locale
	-w /etc/hosts -p wa -k system-locale
	-w /etc/network -p wa -k system-locale
	-w /etc/networks -p wa -k system-locale
	#Ensure events that modify system's MAC are collected
	-w /etc/apparmor/ -p wa -k MAC-policy
	-w /etc/apparmor.d/ -p wa -k MAC-policy
	#Ensure login and logouts events are collected
	-w /var/log/faillog -p wa -k logins
	-w /var/log/lastlog -p wa -k logins
	-w /var/log/tallylog -p wa -k logins
	#Ensure session initiation information is collected
	-w /var/run/utmp -p wa -k session
	-w /var/run/wtmp -p wa -k session
	-w /var/run/btmp -p wa -k session
	#Ensure discretionary access control permission modification events are collected
	-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
	#Ensure unsuccessful unauthorized file access attempts are collected
	-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access
	#Ensure successful file system mounts are collected
	-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
	-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
	#Ensure file deletion events by users are collected
	-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
	-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
	#Ensure changes to system administration scope (ers) is collected
	-w /etc/ers -p wa -k scope
	-w /etc/ers.d -p wa -k scope
	#Ensure system administrator actions (log) are collected
	-w /var/log/.log -p wa -k actions
	#Ensure kernel module loading and unloading is collected
	-w /sbin/insmod -p x -k modules
	-w /sbin/rmmod -p x -k modules
	-w /sbin/modprobe -p x -k modules
	-a always,exit -F arch=b64 -S init_module -S delete_module -k modules
	# increase the buffers to survive stress events. make this bigger for busy systems.
	-b 1024
	# monitor unlink() and rmdir() system calls.
	-a exit,always -S unlink -S rmdir
	# monitor open() system call by Linux UID 1001.
	-a exit,always -S open -F loginuid=1001
	" | sudo tee -a /etc/audit/audit.rules > /dev/null

    sudo systemctl restart auditd.service && sudo augenrules --load && sudo auditctl -l

}
configAUDITD