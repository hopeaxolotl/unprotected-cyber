#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configAPPARMOR () {
    echo "${GREEN}[+] Configurating services APPARMOR '${REPLY}'${RESET}"
    sudo apt install apparmor apparmor-profiles apparmor-utils
    sudo systemctl enable apparmor && sudo systemctl start apparmor.service && sudo update-rc.d apparmor defaults
    sudo apparmor_status
    #Review profiles, making note of dodgy ones, and those that are disabled, but ought not to be"],
    cd /etc/apparmor.d/ && ls,
    #"To list all profiles (including those that are disabled, for instance):",
    find -type d | xargs ls
    #"To disable a profile:",
    sudo ln -s /etc/apparmor.d/{PROFILE.NAME} /etc/apparmor.d/disable/ && sudo apparmor_parser -R /etc/apparmor.d/{PROFILE.NAME}

    sudo systemctl reload apparmor.service

    sudo aa-enforce /etc/apparmor.d/*
    sudo apparmor_status
    sudo rm /etc/apparmor.d/disable/usr.bin.firefox
    sudo apparmor_parser /etc/apparmor.d/usr.bin.firefox
    echo 'GRUB_CMDLINE_LINUX_DEFAULT=\"$GRUB_CMDLINE_LINUX_DEFAULT apparmor=1 security=apparmor\"' | sudo tee -a /etc/grub.d/40-apparmor
    sudo update-grub
    sudo reboot
}

configAPPARMOR