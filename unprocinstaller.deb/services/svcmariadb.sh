#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configMARIADB () {
    echo "${GREEN}[+] Configurating services MARIADB/SQL '${REPLY}'${RESET}"
    sudo apt install mariadb-server
    sudo mysql_secure_installation

    local sslmdb=""
    echo -n "${CYAN} Complete SSL? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $sslmdb in 
        y|Y)
            echo "ssl=on" | sudo tee -a /etc/mysql/my.cnf > /dev/null
            cd /etc/mysql && sudo mkdir ssl && cd ssl
            sudo openssl genrsa 4096 > ca-key.pem
            sudo openssl req -new -x509 -nodes -days 365000 -key ca-key.pem -out ca-cert.pem
            sudo openssl req -newkey rsa:2048 -days 365000 -nodes -keyout server-key.pem -out server-req.pem
            sudo openssl rsa -in server-key.pem -out server-key.pem
            sudo openssl x509 -req -in server-req.pem -days 365000 -CA ca-cert.pem -CAkey ca-key.pem -set_serial 01 -out server-cert.pem
            sudo openssl req -newkey rsa:2048 -days 365000 -nodes -keyout client-key.pem -out client-req.pem
            sudo openssl rsa -in client-key.pem -out client-key.pem
            sudo openssl x509 -req -in client-req.pem -days 365000 -CA ca-cert.pem -CAkey ca-key.pem -set_serial 01 -out client-cert.pem
            sudo openssl verify -CAfile ca-cert.pem server-cert.pem client-cert.pem
            ;;
        n|N)
            echo "felix is gay placeholder"
            ;;
    esac

    sudo chown root:root /etc/mysql/my.cnf
    sudo chmod 644 /etc/mysql/my.cnf
    sudo chown mysql:mysql /var/lib/mysql
    sudo chmod 755 /var/lib/mysql
    
    echo -e "[mysqld]\nbind-address = 127.0.0.1\nssl-ca=/etc/mysql/ssl/ca-cert.pem\nssl-cert=/etc/mysql/ssl/server-cert.pem\nssl-key=/etc/mysql/ssl/server-key.pem\ntls_version = TLSv1.2,TLSv1.3" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "local-infile=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "port = 13306" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "log-error=/var/log/mariadb/mariadb.log" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connect_errors = 3" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "skip-show-database" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "symbolic-links = 0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "default_password_lifetime = 90" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "key_buffer_size = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_allowed_packet = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connections = 2" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo -e "[client]\nssl-ca=/etc/mysql/ssl/ca-cert.pem\nssl-cert=/etc/mysql/ssl/client-cert.pem\nssl-key=/etc/mysql/ssl/client-key.pem\ntls_version = TLSv1.2,TLSv1.3" | sudo tee -a /etc/mysql/my.cnf > /dev/null

    sudo chown -Rv mysql:root /etc/mysql/ssl/
    sudo service mysql restart
}
configMARIADB