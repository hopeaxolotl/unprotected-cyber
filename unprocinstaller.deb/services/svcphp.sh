#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configPHP () {
    echo "${GREEN}[+] Configurating services PHP '${REPLY}'${RESET}"
    sudo apt install php libapache2-mod-php
    sudo apt install php-mysql

    # config wall
    echo "sql.safe_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "safe_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "safe_mode_gid = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "magic_quotes_gpc = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "register_globals = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "track_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "html_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "expose_php = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "mail.add_x_header = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_url_fopen = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_url_include = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "file_uploads = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "post_max_size = 1K" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "upload_max_filesize = 2M" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_input_vars = 100" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_cookies = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_secure = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_only_cookies = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_httponly = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_lifetime = 14400" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_samesite = Strict" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cache_expire = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_strict_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "enable_dl = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "disable_functions = ini_set,php_uname,getmyuid,getmypid,passthru,leak,listen,diskfreespace,tmpfile,link,ignore_user_abord,shell_exec,dl,set_time_limit,exec,system,highlight_file,source,show_source,fpaththru,virtual,posix_ctermid,posix_getcwd,posix_getegid,posix_geteuid,posix_getgid,posix_getgrgid,posix_getgrnam,posix_getgroups,posix_getlogin,posix_getpgid,posix_getpgrp,posix_getpid,posix,_getppid,posix_getpwnam,posix_getpwuid,posix_getrlimit,posix_getsid,posix_getuid,posix_isatty,posix_kill,posix_mkfifo,posix_setegid,posix_seteuid,posix_setgid,posix_setpgid,posix_setsid,posix_setuid,posix_times,posix_ttyname,posix_uname,proc_open,proc_close, proc_get_status,proc_nice,proc_terminate,phpinfo,popen,curl_exec,curl_multi_exec,parse_ini_file,allow_url_fopen,allow_url_include,pcntl_exec,chgrp,chmod,chown,lchgrp,lchown,putenv" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_execution_time = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_input_time = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "memory_limit = 8M" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "report_memleaks = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_startup_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "error_reporting = E_ALL" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "log_errors = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "error_log = /var/log/php-scripts.log" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "ignore_repeated_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "output_buffering = 4096" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "register_argc_argv = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "request_order = \"GP\"" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "variables_order = \"GPCS\"" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_webdav_methods = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.gc_maxlifetime = 600" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "short_open_tag=off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "cgi.force_redirect = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "cgi.discard_path=1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.bug_compat_42 = 0" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.bug_compat_warn = 0" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null

    service restart php
    service restart apache2
}
configPHP