#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configPROFTPD () {
    echo "${GREEN}[+] Configurating services PROFTPD '${REPLY}'${RESET}"
    sudo ufw allow ftp 
    sudo ufw allow 20
    
    #ready for a config wall guys
    echo "Deny Filter \\*.*/" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "DelayEngine on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseLastLog on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "SetLastLog on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "IdentLookups off" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSEngine on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSProtocol SSLv23" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseReverseDNS on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseIPv6 off" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxInstances 10" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxClients 10" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxLoginAttempts 10 'Maximum number of allowed users are already connected (%m)" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "AllowFilter \"^[a-zA-Z0-9 ,]*$\"" | sudo tee -a /etc/proftpd/proftpd.conf

    echo "TLSEngine on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSProtocol SSLv23" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSLog /var/log/proftpd/tls.log" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSVerifyClient off" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSOptions dNSNameRequired iPAddressRequired" | sudo tee -a /etc/proftpd/tls.conf

    sudo service restart proftpd
}
configPROFTPD