#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configSAMBA() {
    echo "${GREEN}[+] Configurating services SAMBA '${REPLY}'${RESET}"
    # Unique config file each time
    sudo cp /etc/samba/smb.conf backup/services/smb_conf_`date +%s`.bak

    sudo ufw allow samba

    # smb.conf 
    echo "restrict anonymous = 2"       | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "encrypt passwords = yes"      | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "read only = yes"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "ntlm auth = no"               | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "obey pam restrictions = yes"  | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "server signing = mandatory"   | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "smb encrypt = mandatory"      | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "min protocol = SMB2"          | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "protocol = SMB2"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "guest ok = no"                | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "max log size = 24"            | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "disable netbios = yes"        | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "smb ports = 445"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "printcap name = /dev/null"    | sudo tee -a /etc/samba/smb.conf > /dev/null


    echo "${YELLOW}Please read the samba file ${BOLD}/etc/samba/smb.conf${RESET}${YELLOW} as well and check its contents${RESET}"

    sudo systemctl restart smbd && sleep 3 && sudo systemctl status smbd
    sudo smbpasswd -a "$CCUSER"
}
configSAMBA