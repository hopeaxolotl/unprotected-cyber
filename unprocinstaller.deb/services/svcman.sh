#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
installPSPY () { 
    echo "${GREEN}[+] Configurating services PSPY '${REPLY}'${RESET}"
    wget "https://github.com/DominicBreuker/pspy/releases/download/v1.2.0/pspy64" -O backup/misc/pspy 
    chmod +x backup/misc/pspy 

    sudo backup/misc/pspy | tee backup/misc/pspy_output_`date +%s`.log > /dev/null &
}
installLINENUM () {
    echo "${GREEN}[+] Configurating services LINENUM '${REPLY}'${RESET}"
    wget "https://raw.githubusercontent.com/rebootuser/LinEnum/master/LinEnum.sh" -O backup/misc/linenum.sh
    chmod +x backup/misc/linenum.sh

    backup/misc/linenum.sh -t | tee backup/misc/linenum_output_`date +%s`.log > /dev/null &
}
compiler_manservices () {
    installPSPY
    installLINENUM
}

compiler_manservices