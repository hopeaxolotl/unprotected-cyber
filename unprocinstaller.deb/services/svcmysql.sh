#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configMYSQL () {
    echo "${GREEN}[+] Configurating services MYSQL '${REPLY}'${RESET}"
    sudo ufw allow mysql 
    sudo apt install mysql-server
    sudo sysyemctl enable mysql
    sudo mysql_secure_installation

    local sslmsql=""
    echo -n "${CYAN} Complete SSL? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $sslmsql in 
        y|Y)
            echo "ssl=on" | sudo tee -a /etc/mysql/my.cnf > /dev/null
            sudo mkdir -p /etc/certs
            sudo cd /etc/certs
            sudo openssl genrsa 2048 > ca-key.pem
            sudo openssl req -new -x509 -nodes -days 3600 -key ca-key.pem -out ca.pem
            sudo openssl req -newkey rsa:2048 -days 3600 -nodes -keyout server-key.pem -out server-req.pem
            sudo openssl rsa -in server-key.pem -out server-key.pem
            sudo penssl x509 -req -in server-req.pem -days 3600 -CA ca.pem -CAkey ca-key.pem -set_serial 01 -out server-cert.pem
            sudo openssl req -newkey rsa:2048 -days 3600 -nodes -keyout client-key.pem -out client-req.pem
            sudo openssl rsa -in client-key.pem -out client-key.pem
            sudo openssl x509 -req -in client-req.pem -days 3600 -CA ca.pem -CAkey ca-key.pem -set_serial 01 -out client-cert.pem
            sudo openssl verify -CAfile ca.pem server-cert.pem client-cert.pem
            ;;
        n|N)
            echo "felix is gay placeholder"
            ;;
    esac

    sudo chown root:root /etc/mysql/my.cnf
    sudo chmod 644 /etc/mysql/my.cnf
    sudo chown mysql:mysql /var/lib/mysql
    sudo chmod 755 /var/lib/mysql

    sudo rm -rf ~/.mysql_history

    echo "local-infile=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "log_error=/var/log/mysql/error.log" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "skip-show-database" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "bind-address=127.0.0.1" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "symbolic-links=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "default_password_lifetime = 90" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "key_buffer_size         = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_allowed_packet      = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connections = 20" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "[mysqld]" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "user = sqlroot" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "password = Fus1()n123" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "port=3360" | sudo tee -a /etc/mysql/my.cnf > /dev/null

    sudo chown -R mysql:mysql /etc/certs/
    sudo chmod 600 client-key.pem server-key.pem ca-key.pem

    sudo service mysql restart
    sudo service mysqld restart
}
configMYSQL