#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configBIND9 () {
    echo "${GREEN}[+] Configurating services BIND9 '${REPLY}'${RESET}"
    sudo apt install bind9 bind9utils.

    echo "OPTIONS=\"-u bind -4\"" | sudo tee -a /etc/default/bind9 < /dev/null

    echo "include \"/etc/bind/named.conf.options\";" | sudo tee -a /etc/bind/named.conf < /dev/null
    echo "include \"/etc/bind/named.conf.local\";" | sudo tee -a /etc/bind/named.conf < /dev/null
    echo "include \"/etc/bind/named.conf.default-zones\";" | sudo tee -a /etc/bind/named.conf < /dev/null

    echo "acl \"trusted\" { [local ip]; };" | sudo tee -a /etc/bind/named.conf.options
    echo "recursion no;" | sudo tee -a /etc/bind/named.conf.options
    echo "allow-recursion { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "listen-on { [local ip]; };" | sudo tee -a /etc/bind/named.conf.options
    echo "allow-transfer { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "forwarders { 8.8.8.8; 8.8.4.4; };" | sudo tee -a /etc/bind/named.conf.options
    echo "dnssec-validation yes;" | sudo tee -a /etc/bind/named.conf.options
    echo "auth-nxdomain no;" | sudo tee -a /etc/bind/named.conf.options
    echo "listen-on-v6 { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "server-id none;" | sudo tee -a /etc/bind/named.conf.options
    echo "version none;" | sudo tee -a /etc/bind/named.conf.options

    echo "zone \"mydomain.com\" {" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  type master;" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  file \"/etc/bind/zones/db.mydomain.com\";" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  allow-transfer { none; };" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "};" | sudo tee -a /etc/bind/named.conf.local > /dev/null

    sudo systemctl restart bind9 && sudo systemctl status bind9
}
configBIND9