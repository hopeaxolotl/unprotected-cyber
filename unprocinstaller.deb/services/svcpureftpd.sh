#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configPUREFTPD () {
    echo "${GREEN}[+] Configurating services PUREFTPD '${REPLY}'${RESET}"

    sudo cp /etc/pure-ftpd/pure-ftpd.conf backup/services/pure-ftpd_conf_`date +%s`.bak
    # Unique config file each time
    sudo ufw allow ftp 
    sudo ufw allow 20

    # pure-ftpd.conf

    echo "ChrootEveryone yes"           | sudo tee /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "NoAnonymous yes"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousOnly no"             | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousCanCreateDirs no"    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousCantUpload yes"      | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AllowUserFXP no"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AllowAnonymousFXP no"         | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "DisplayDotFiles yes"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "ProhibitDotFilesWrite yes"    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "ProhibitDotFilesRead no"      | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "DontResolve yes"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "VerboseLog yes"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "SyslogFacility ftp"           | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "PAMAuthenticate yes"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "UnixAuthenticate no"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "MaxClientsNumber 50"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "LimitRecursion 500 8"         | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxClientsPerIp 3"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxIdleTime 10"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxLoad 4"                    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "IPV4Only yes"                 | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "TLS 2"                        | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "Umask 133:022"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "Daemonize yes"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "NoChmod yes"                  | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    # echo "KeepAllFiles yes"             | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "CreateHomeDir yes"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AutoRename yes"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AntiWarez yes"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "CustomerProof yes"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    sudo service pure-ftpd restart 
}

configPUREFTPD