#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ configurations ------------------------------
configAPACHE2 () {
    echo "${GREEN}[+] Configurating services APACHE2 '${REPLY}'${RESET}"
    sudo cp /etc/apache2/apache2.conf backup/services/apache2_conf_`date +%s`.bak
    sudo cp /etc/apache2/conf-available/security.conf backup/services/apache2_security_conf_`date +%s`.bak

    sudo ufw allow apache
    sudo ufw allow https 
    sudo ufw allow http

    local answer=""
    echo -n "${CYAN}Remove default index.html [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo "" | sudo tee /var/www/html/index.html
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo "HostnameLookups Off"              | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "LogLevel warn"                    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "ServerTokens Prod"                | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "ServerSignature Off"              | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Options all -Indexes"             | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Header unset ETag"                | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Header always unset X-Powered-By" | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "FileETag None"                    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "TraceEnable off"                  | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Timeout 60"                       | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    
    echo "RewriteEngine On"                         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo 'RewriteCond %{THE_REQUEST} !HTTP/1\.1$'   | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo 'RewriteRule .* - [F]'                     | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    echo '<IfModule mod_headers.c>'                         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo '    Header set X-XSS-Protection 1;'               | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo '</IfModule>'                                      | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    # Secure /
    echo "<Directory />"            | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options -Indexes"     | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    AllowOverride None"   | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Order Deny,Allow"     | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options None"         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Deny from all"        | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "</Directory>"             | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    
    # Secure /var/www/html
    echo "<Directory /var/www/html>"    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options -Indexes"         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "</Directory>"                 | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    # security.conf
    # Enable HTTPOnly and Secure Flags
    echo 'Header edit Set-Cookie ^(.*)\$ \$1;HttpOnly;Secure'                                   | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Clickjacking Attack Protection
    echo 'Header always append X-Frame-Options SAMEORIGIN'                                      | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # XSS Protection
    echo 'Header set X-XSS-Protection "1; mode=block"'                                          | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Enforce secure connections to the server
    echo 'Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"'    | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null  

    # MIME sniffing Protection
    echo 'Header set X-Content-Type-Options: "nosniff"'                                         | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Prevent Cross-site scripting and injections
    echo 'Header set Content-Security-Policy "default-src '"'self'"';"'                         | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

	# Secure root directory
    echo "<Directory />"            | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Options -Indexes"       | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  AllowOverride None"     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Order Deny,Allow"       | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Deny from all"          | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "</Directory>"             | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Secure html directory
    echo "<Directory /var/www/html>"        | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Options -Indexes -Includes"     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  AllowOverride None"             | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Order Allow,Deny"               | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Allow from All"                 | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "</Directory>"                     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    #ports.conf
    echo "Listen 80" | sudo tee -a /etc/apache2/ports.conf
    echo "    Listen 443" | sudo tee -a /etc/apache2/ports.conf
    echo "</IfModule>" | sudo tee -a /etc/apache2/ports.conf
    echo "<IfModule mod_gnutls.c>" | sudo tee -a /etc/apache2/ports.conf
    echo "    Listen 443" | sudo tee -a /etc/apache2/ports.conf
    echo "</IfModule>" | sudo tee - a /etc/apache2/ports.conf

    #some other cmds i found, its in apache2.json but idk what it is so id just leave it in unless YOU KNOW WHAT IT IS BRODIE!!
    sudo apt install libapache2-mod-security2
    cp /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf
    sudo nano /etc/modsecurity/modsecurity.conf
    LoadModule evasive20_module modules/mod_evasive24.so
    LoadModule security2_module modules/mod_security2.so
 
    # ssl.conf
    # TLS only
    sudo sed -i "s/SSLProtocol.*/SSLProtocol –ALL +TLSv1 +TLSv1.1 +TLSv1.2/" /etc/apache2/mods-available/ssl.conf
    # Stronger cipher suite
    sudo sed -i "s/SSLCipherSuite.*/SSLCipherSuite HIGH:\!MEDIUM:\!aNULL:\!MD5:\!RC4/" /etc/apache2/mods-available/ssl.conf

    sudo chown -R root:root /etc/apache2
    sudo chown -R root:root /etc/apache 2> /dev/null

    sudo service apache2 restart && sleep 3 && sudo service apache2 status
}
configAPACHE2