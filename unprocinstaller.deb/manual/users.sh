#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ compiler_userfunctions functions ------------------------------

delete_unauthorised_users () {
    echo -e $USERS | sed "s/ /\\n/g" > accusers.txt
    local INVALID=$(diff -n --suppress-common-lines users.txt accusers.txt | cut -d" " -f5-)

    for user in $INVALID
    do 
       	echo "${YELLOW}[!] Removing user: ${user}${RESET}"
       	sudo userdel -r $user
    done
    rm accusers.txt
}

delete_unauthorised_sudoers () {
    local SUDOERS=$(grep "sudo" /etc/group | cut -d":" -f4 | sed "s/,/ /g") 

    echo -e $SUDOERS | sed "s/ /\\n/g" > accsudoers.txt
    local INVALID=$(diff -n --suppress-common-lines sudoers.txt accsudoers.txt | cut -d" " -f5-)
    for sudoer in $INVALID
    do 
        echo "${YELLOW}[!] Removing sudoer: ${sudoer}${RESET}"
        sudo gpasswd -d $sudoer sudo
    done

    rm accsudoers.txt
}

add_new_users () {
    echo "$Type 'exit' to stop."
    echo -n "${CLEARSCREEN}"
    echo "${RED}${BOLD}Type 'exit' to skip/stop.${RESET}"
    while read -r -p "Username to create: " && [[ $REPLY != exit ]]; do 
        echo "${GREEN}[+] Added new user and creating new home directory '${REPLY}'${RESET}"
        sudo useradd -m $REPLY
        sudo passwd -e $REPLY
    done
}

change_users_passwords () {
    # Changes everyone's password to Fus1()n123
    echo "${GREEN}[+] Changing user passwords '${REPLY}'${RESET}"
    for user in $USERS
    do 
    	echo $i:'Fus1()n123' | sudo chpasswd
	    sudo chage -d 0 $i
    sudo chage -I 30 
    done
}

user_misc () {
    echo "${GREEN}[+] Miscellaneous user options '${REPLY}'${RESET}"
    sudo passwd -l root
    sudo usermod -p '!' root
    echo > /etc/securetty
    sudo passwd -d root

    echo "INACTIVE=30" | sudo tee -a /etc/default/useradd > /dev/null
    echo "TMOUT=300"   | sudo tee -a /etc/environment > /dev/null
}

users_check_uid_0 () {
    local UIDS=$(cut /etc/passwd -d: -f1,3 | grep -v root)
    for i in $UIDS
    do 
        local username=$(echo $i | cut -d: -f1)
        local user_uid=$(echo $i | cut -d: -f2)
        if [[ $user_uid -eq "0" ]]
        then 
            echo "${RED}${BOLD}Found a root UID user [${username} : uid ${user_uid}] !${RESET}"
            read -rp $'Press <enter> to continue\n'
        fi
    done
}   

check_shadow_password () { 
    local SHADOW=$(sudo cat /etc/shadow)
    for line in $SHADOW
    do 
        local password_hash=$(echo $line | cut -d: -f2)
        local account=$(echo $line | cut -d: -f1)
        if [[ -z $password_hash  ]]
        then 
            echo "${RED}${BOLD}Empty password${RESET}${RED} for account ${RED}${BOLD}${account}${RESET}${RED} found in ${RED}/etc/shadow!${RESET}"
            read -rp $'Press <enter> to continue\n'
        fi
    done
}

compiler_userfunctions () {
    local answer=""
    echo -n "${CYAN}Delete unauthorised users? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo 
            echo "${CYAN}Press <enter> after adding ${BOLD}./users.txt${RESET}"
            read -r
            delete_unauthorised_users
            ;;
        n|N)
            ;; # Do
    esac

    echo -n "${CYAN}Delete unauthorised sudoers? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo
            echo "${CYAN}Press <enter> after adding ${BOLD}./sudoers.txt${RESET}"
            read -r
            delete_unauthorised_sudoers
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo -n "${CYAN}Add users? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            add_new_users 
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo -n "${CYAN}Change all users passwords? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            change_users_passwords 
            ;;
        n|N)
            ;; # Do nothing
    esac
    
    users_check_uid_0
    check_shadow_password
    user_misc
}

compiler_userfunctions