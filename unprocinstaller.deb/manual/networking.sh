#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ compiler_networking functions ------------------------------
networking_sysctl_config () {
    echo "${GREEN}[+] Network Config '${REPLY}'${RESET}"
    sudo touch /etc/sysctl.d/cybercent-networking.conf

    # General IPv4 stuff updated by Liam
    echo net.ipv4.ip_forward=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.core.bpf_jit_harden=1 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null

    # IPv4 TIME-WAIT assassination protection
    echo net.ipv4.tcp_rfc1337=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null # Scored

    # IP Spoofing protection, Source route verification  
    echo net.ipv4.conf.all.rp_filter=1      | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.rp_filter=1  | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Ignore ICMP broadcast requests
    echo net.ipv4.icmp_echo_ignore_broadcasts=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Ignore Directed pings
    echo net.ipv4.icmp_echo_ignore_all=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Log Martians
    echo net.ipv4.conf.all.log_martians=1               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.icmp_ignore_bogus_error_responses=1   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Disable source packet routing
    echo net.ipv4.conf.all.accept_source_route=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.accept_source_route=0    | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.accept_source_route=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_source_route=0    | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Block SYN attacks
    echo net.ipv4.tcp_syncookies=1          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_max_syn_backlog=2048  | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_synack_retries=2      | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_syn_retries=2         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null # Try values 1-5

    # Ignore ICMP redirects
    echo net.ipv4.conf.all.send_redirects=0         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.send_redirects=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.accept_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.accept_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.secure_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.secure_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    echo net.ipv6.conf.all.send_redirects=0         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.default.send_redirects=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.all.accept_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.secure_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.default.secure_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 

    echo net.ipv6.conf.default.router_solicitations=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_rtr_pref=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_pinfo=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_defrtr=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.autoconf=0               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.dad_transmits=0          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.max_addresses=1          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.disable_ipv6=1               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.lo.disable_ipv6=1                | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # sudo sysctl -p /etc/sysctl.d/cybercent.conf <--- UNCOMMENT THIS LINE!!!
    sudo sysctl --system

    echo 'blacklist ipv6' | sudo tee -a /etc/modprobe.d/blacklist > /dev/null
}

configUFW () {
    echo "${GREEN}[+] Configurating UFW/iptables '${REPLY}'${RESET}"
    sudo iptables -F
    sudo iptables -X
    sudo iptables -Z

    sudo $APT install -y ufw
    sudo ufw status verbose > backup/networking/firewall_ufw_before.log 
    echo "y" | sudo ufw reset
    sudo ufw enable 
    sudo ufw logging full

    sudo ufw default reject incoming 
    sudo ufw default allow outgoing

    sudo ufw deny 23  
    sudo ufw deny 2049  
    sudo ufw deny 515  
    sudo ufw deny 111   
    sudo ufw status verbose > backup/networking/firewall_ufw_after.log 

    # Iptables specific
    # Block null packets (DoS)
    sudo iptables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
    # Block syn-flood attacks (DoS)
    sudo iptables -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
    #Drop incoming packets with fragments
    sudo iptables -A INPUT -f -j DROP
    # Block XMAS packets (DoS)
    sudo iptables -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
    # Allow internal traffic on the loopback device
    sudo iptables -A INPUT -i lo -j ACCEPT
    # sudo iptables -A INPUT -p tcp -m tcp --dport 22 -j ACCEPT
    # Allow established connections
    sudo iptables -I INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    # Allow outgoing connections
    sudo iptables -P OUTPUT ACCEPT
    # Set default deny firewall policy
    sudo iptables -P INPUT DROP
    #Block Telnet
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 23 -j DROP
    #Block NFS
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 2049 -j DROP
    #Block X-Windows
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 6000:6009 -j DROP
    #Block X-Windows font server
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 7100 -j DROP
    #Block printer port
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 515 -j DROP
    #Block Sun rpc/NFS
    sudo iptables -A INPUT -p udp -s 0/0 -d 0/0 --dport 111 -j DROP
    # Deny outside packets from internet which claim to be from your loopback interface.
    sudo iptables -A INPUT -p all -s localhost  -i eth0 -j DROP
    # Save rules
    sudo iptables-save > /etc/sudo iptables/rules.v4
}

log_current_processes () {
    # Full process list 
    echo "${GREEN}[+] Logging processes '${REPLY}'${RESET}"
    ps auxef > backup/misc/all_processes_`date +%s`.log
    ps auxe | grep -E "^root" > backup/misc/root_processes_`date +%s`.log 
}

monitor_ports () { 
    echo "${GREEN}[+] Logging ports '${REPLY}'${RESET}"
    # Pipes open tcp and udp ports into a less window
    sudo netstat -peltu | column -t > backup/networking/open_ports.log

    sudo $APT install nmap -y
    sudo nmap -oN backup/networking/nmap.log -p- -v localhost 
    sudo $APT purge nmap -y
}

compiler_networking () {
    networking_sysctl_config
    configUFW
    log_current_processes
    monitor_ports
}