#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ compiler_startup functions ------------------------------

chattr_all_config_files () {
    sudo find /etc/ -type f -exec chattr -i {} \;
    sudo find /bin/ -type f -exec chattr -i {} \;
    sudo find /home/ -type f -exec chattr -i {} \;
}

startup_scripts () {
    # Get all init scripts
    echo "${GREEN}[+] Gathering Scripts '${REPLY}'${RESET}"
    ls -la /etc/init/ > backup/services/startup/init_scripts.log
    ls -la /etc/init.d/ >> backup/services/startup/init_scripts.log

    # Get all rc scripts
    ls -la /etc/rc*.d > backup/services/startup/rc_scripts.log

    # Backup and fix rc.local
    local good_rc_local="#!/bin/sh -e\nexit 0"
    sudo cp /etc/rc.local backup/services/startup/rc_local_`date +%s`.bak 
    echo -e '#!/bin/sh -e\nexit 0' | sudo tee /etc/rc.local > /dev/null

    # Find all newly edited files in /etc/
    echo "${GREEN}[*] Files edited recently in backup/misc ${RESET}"
    sudo find /etc/ -type f -newermt 2020-09-01 -ls | tee backup/misc/config_files_edited_since_sept_2020.log > /dev/null
    sudo find /etc/ -type f -mtime -3 -ls | tee backup/misc/config_files_edited_last_3_days.log > /dev/null
}

# ------------------------------ COMPILE NOW!! ------------------------------

compiler_startup() {
    echo " ${GREEN} Unprotected Cyber System Hardening Script ${RESET}" 
    echo "Thanks to the creators of I am Root Script and Gl0ckrain"
	sleep 1
    echo "${YELLOW} This version of the script is highly experimental ${RESET}"
	echo "${RED}*STOP!* Forensic questions must be completed before as this script will break and delete certain aspects of the machine. ${RESET}"
	echo Press enter to continue when all these things have been done:
	read -p "" prompt
    clear
    nano services.txt
    nano users.txt
    nano sudoers.txt
	echo "${GREEN} Please now copy all allowed users to users.txt, all sudoers to sudoers.txt and all critical services to services.txt, press enter to continue ${RESET}"
	read -p "" prompt
    clear
	sleep 1
    echo "${GREEN} Making backup directories {$RESET}"

    mkdir -p backup/users
    mkdir -p backup/pam
    mkdir -p backup/apt
    
    mkdir -p backup/services
    mkdir -p backup/services/crons
    mkdir -p backup/services/startup

    mkdir -p backup/networking
    mkdir -p backup/system
    mkdir -p backup/malware

    mkdir -p backup/misc
    mkdir -p backup/misc/media

    echo "${GREEN}[*] Giving permissions to necessary files ... ${RESET}"
    chattr_all_config_files

    clear
    sleep 2
    startup_scripts

}

compiler_startup