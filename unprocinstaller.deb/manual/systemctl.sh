#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ compiler_system functions ------------------------------

file_permissions () {
    echo "${GREEN}[+] Changing like a billion file permissions for system files'${REPLY}'${RESET}"
    sudo chmod 700 "/home/$CCUSER"
    sudo chown "$CCUSER" "/home/$CCUSER"
    sudo chgrp "$CCUSER" "/home/$CCUSER"

    #compare with gtfobins.github.io (thx luka)
    sudo find / -perm /4000 #suid
    sudo find / -perm /2000 #guid
    sudo find / -perm /6000 #both

    #check file capabilities
    sudo getcap -r / 2>/dev/null
    
    #give file user/group
    find / -nouser
    find / -nogroup

    find / -type f -perm 0777

    sudo find / -type d -perm -002 ! -perm -1000
    sudo chmod +t [directory]

    #perms for gen sys files
    sudo chown root:root /etc/passwd
    sudo chmod 644 /etc/passwd
    sudo chown root:root /etc/passwd-
    sudo chmod u-x,go-wx /etc/passwd-

    sudo chown root:shadow /etc/shadow
    sudo chmod 400 /etc/shadow
    sudo chown root:shadow /etc/shadow-
    sudo chmod 400 /etc/shadow-

    sudo chown root:shadow /etc/gshadow
    sudo chmod 400 /etc/gshadow
    sudo chown root:shadow /etc/gshadow-
    sudo chmod 400 /etc/gshadow-

    sudo chown root:root /etc/group
    sudo chmod 644 /etc/group
    sudo chown root:root /etc/group-
    sudo chmod u-x,go-wx /etc/group-
    
    sudo chown root:root /etc/security/opasswd
    sudo chmod 600 /etc/security/opasswd

    sudo chown root:root /etc/sudoers
    sudo chmod 440 /etc/sudoers
    sudo chown root:root /etc/sudoers.d/*
    sudo chmod 440 /etc/sudoers.d/*

    sudo chown root:root /etc/securetty
    sudo chmod 600 /etc/securetty
    sudo chown root:root /etc/ftpusers
    sudo chmod 640 /etc/ftpusers
    sudo chown root:root /etc/inetd.conf
    sudo chmod 440 /etc/inetd.conf
    sudo chown root:root /etc/xinetd.conf
    sudo chmod 440 /etc/xinetd.conf
    sudo chown root:root /etc/inetd.d
    sudo chmod 400 /etc/inetd.d
    sudo chown root:root /etc/inetd.d/*
    sudo chmod 400 /etc/inetd.d/*
    sudo chown root:root /etc/hosts.allow
    sudo chmod 644 /etc/hosts.allow
    sudo chown root:root /etc/ers
    sudo chmod 440 /etc/ers
    sudo chown root:root /etc/fstab
    sudo chmod 644 /etc/fstab
    sudo chown root:root /boot/grub/grub.cfg
    sudo chmod 600 /boot/grub/grub.cfg

    sudo chown root:root /etc/crontab
    sudo chmod 600 /etc/crontab
    sudo chown root:root /etc/cron.hourly
    sudo chmod 600 /etc/cron.hourly
    sudo chown root:root /etc/cron.daily
    sudo chmod 600 /etc/cron.daily
    sudo chown root:root /etc/cron.weekly
    sudo chmod 600 /etc/cron.weekly
    sudo chown root:root /etc/cron.monthly
    sudo chmod 600 /etc/cron.monthly
    sudo chown root:root /etc/cron.d
    sudo chmod 600 /etc/cron.d
    sudo chown root:root /etc/cron.allow
    sudo chmod 600 /etc/cron.allow
    sudo chown root:root /etc/cron.deny
    sudo chmod 600 /etc/cron.deny

}

disable_ctrlaltdel () {
    echo "${GREEN}[+] Disabling CTRL+ALT+DEL '${REPLY}'${RESET}"
    sudo systemctl mask ctrl-alt-del.target
    echo 'exec shutdown -r now "Control-Alt-Delete pressed"' | sudo tee -a /etc/init/control-alt-delete.conf
    echo "CtrlAltDelBurstAction=none" | sudo tee -a /etc/systemd/system.conf > /dev/null
    sudo systemctl daemon-reload
}

system_sysctl_config() {
    echo "${GREEN}[+] Kernel config '${REPLY}'${RESET}"
    sudo touch /etc/sysctl.d/cybercent-system.conf

    echo kernel.dmesg_restrict=1            | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored
    echo kernel.msgmnb=65536                | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.msgmax=65536                | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.sysrq=0                     | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.maps_protect=1              | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.core_uses_pid=1             | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.shmmax=68719476736          | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.shmall=4294967296           | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.exec_shield=1               | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.panic=10                    | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.kptr_restrict=2             | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.randomize_va_space=2        | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored ASLR; 2 = full; 1 = semi; 0 = none
    echo kernel.unprivileged_userns_clone=0 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored
    echo kernel.ctrl-alt-del=0              | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored CTRL-ALT-DEL disable
    echo kernel.yama.ptrace_scope=2         | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.core_pattern = "/bin/false" | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo vm.panic_on_oom=1                  | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo fs.suid_dumpable=0                 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Core dumps # Scored
    echo fs.protected_hardlinks=1           | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo fs.protected_symlinks=1            | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo user.max_user_namespaces=0 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null

    sudo sysctl --system
}

compiler_system () {
    system_sysctl_config
    file_permissions
    local answer=""
    echo -n "${CYAN}Disable Ctrl-Alt-Delete? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo 
            disable_ctrl_alt_del
            ;;
        n|N)
            ;;
    esac
}

compiler_system