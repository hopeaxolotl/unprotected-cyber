import sys
import subprocess
from automatic import load_automatic_content
from manual import load_man_content
from docs import load_docs_content
from PyQt5.QtWidgets import (
    QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget, QHBoxLayout, QTextEdit, QMessageBox
)
from PyQt5.QtGui import QPixmap, QFont, QFontDatabase
from PyQt5.QtCore import QTimer, Qt

class TextDisplayWidget(QWidget):
    def __init__(self):
        super().__init__()

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("background-color: black; color: green; padding: 20px")
        self.text_edit.setFont(QFont("Courier New", 12))

        layout = QVBoxLayout()
        layout.addWidget(self.text_edit)
        self.setLayout(layout)
    
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_text)
        self.lines = [
            "▒▓▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓      ▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▓▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓████    ████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██  ░░▓▓▒░  ██▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▓▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█ ░███████▓▒ █▓▓▓▓▓▓███████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█  ███████▓▓ █▓▓▓▓▓▓▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█ ░▒   ▓   ░ █▓▓▓▓▒▒▓▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█░▒██▓▓█░▒█▓ █▓▓▓▒▒▓▓▒▓▓▓▓▒▓▓▒▓▓▓▓▓▓███▓▓▓▓███▓▓▓▓▓▓▓▓",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓██░▓░▓▒░.░░░░█▓▓▓▒▓▓▓▒▓▓▓▓▒▓▓▓▓▓▓▓▓▓█░██████ ▓▓▓▓▓▓▓▓▓",
            "▓▓▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓█▓▒▒▓██▓▒▒ ██▓▓▓▒▓▓▓▒▒▓▓▓▓▒▒▒▓▓▓▓▓██   █   ██▓▓▓▓▓▓▓▓",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███░░▒▓▓▓░░███▓▓▓▓▒▓▓▒▒▒▓▓▓▒▓▓▓▓█████    ▓███▓▓▓▓▓▓▓██",
            "▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓███▒░▒▓▒░░░ ░░░██████▒▓▓▓▒▒▓▒▒▒▓████ ░    ▒███▓▓▓▓▓▓▓▓▒▒▒",
            "█▓▓▓▓▓▓▓▓▓▓▓███▓░░▒░▒██▓░░░▓▒     ▒███▓▒▒▓▓▓████      ▓████▓▓▓▓▓▓▓▓▓▓▓▓▓",
            " █▓▓▓▓▓▓▓▓███  ▒░░▓▒▓░░░▒▒░░░▒▓▒▒▒░░ ▒▓▓▓███░        ███▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            " █▓▓▓▓▓▓▓█▓░░░▒█░░▓▒▒▓▒▒▓▒▒▓▒▒▓█▒▓▒█ ░███▒   █   █ ████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            " █▓▓▓▓▓▓▓█▓░░░▒█░░▓▒▒▓▒▒▓▒▒▓▒▒▓█▒▓▒█ ░███▒   █   █ ████▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            " █▓▓▓▓▓██░▒░▓▒░█░▒▓▓███▓░▓█▒█▓▒░░▒▓░▓▓    ▓█████ ░███▓▓▓▓▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒",
            "▒▓▓▓▓▓██░▒▓▓░▓░▓ ▒▒    ░▓█▓░░▒░▒ ▒    ░▓░  █▒ ▒ ████▓▓▓▓▓▓▓▓▓▒▒▒▒▒▒▒▓▓▓▓",
            "▓▓▓▓▓██ ▓▒▓▒▓ ░█░░  ███▒░ ░░░▒ ░░░ ░░░   ░ ░▓▓▓▓██▓▓███▓▓▓▓▓▒▓▓▒▒▒▓▓▓▒▓▓",
            "▓▓▓▓██ ▓▓▒▓░▓█ ▒▒ ███   █  ░░░    ▒░░░██▓██▒▒▓▓▒▒▓▓▓▓▓▓▓▓▒▒▓▓▒▒▒▒▓▓▒▒▓▓▓",
            "▓▓▓██ ░▓▒▒▒▒▒▒▓ ░ ████░██ ░░   ██ ░░░  ▓ ░▒ ▓▓▒▒▒▒▒▓▓▒▒▓▒▒▒▒▒▒▒▓▓▒▒▒▓▓▓▓",
            "▓▓▓▓░░▓▓▒▓▒▓░░█▓▓▓░ ▒██▒    ▒██  ░░ ░░░ ░▒░░█▒▒▒▒▒▒▒▒▒▓▒▒▒▓▓▓▓▓▒▒▓▓▓▓▓▓▓",
            "▓▓▓▒  ▒░░▒░▒▒░░░ █▓░   ▒▓ ███     ░░░░  ▒▒░▓▓▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓███▓▓▓▓▓▓",
            "▓▓▓████████▒   ██▓       ███████▓▓▒▒░░███░ ▓▓▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓",
            "▒▓▓▓░▓▒░    █▒     ▒▓█████████▒█░░░░ ░░░░░█▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▓▓▓▒▓▓▓▓▓▓▓",
            "▓▓▓▓▒▓▒▓███▒▒▓█████████████▒  ░░ ░▓▒░▒ ░▓▓▓▒▒▒▒▒▒▒▒▒▒▒▒▒▒▓▒▒▓▓▓▓▓▓▓▓▓▓▓▓",
        ]
        
        self.current_line = 0
        self.timer.start(150)

    def update_text(self):
        if self.current_line < len(self.lines):
            self.text_edit.append(self.lines[self.current_line])
            self.current_line += 1
        else:
            self.timer.stop()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.load_font()

        self.setWindowTitle('Unprotected Cyberscript')
        self.setFixedSize(1366, 768)

        self.text_widget = TextDisplayWidget()
        self.setCentralWidget(self.text_widget)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self.show_menu)
        self.switch_timer.setSingleShot(True)
        self.switch_timer.start(3600)

    def load_font(self):
        font_path = "fonts/Chalet LondonNineteenSixty Regular.otf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            print(f"Font loaded: {font_family}")
        else:
            print("Failed to load font. Please check the font path and file.")

    def show_menu(self):
        self.background_label = QLabel()
        self.background_label.setPixmap(QPixmap("backgrounds/background.png"))
        self.background_label.setScaledContents(True)
        self.background_label.setFixedSize(self.size())

        menu_overlay = QWidget()
        menu_overlay.setAttribute(Qt.WA_TranslucentBackground)
        menu_layout = QVBoxLayout(menu_overlay)

        button_layout = QHBoxLayout()
        button_layout.setSpacing(60)
        button_layout.addStretch(1)
        button_layout.setContentsMargins(0, 0, 0, 0)

        button_names = ["EXIT", "DOCS", "LEGACY", "MANUAL", "AUTO"]
        for name in button_names:
            button = QPushButton(name)
            button.setFont(QFont("Chalet London Nineteen Sixty", 19))
            button.setStyleSheet("""
                QPushButton {
                    color: gray;
                    background: none;
                    border: none;
                    padding: 0px;
                }
                QPushButton:hover {
                    color: white; 
                }
            """)
            button_layout.addWidget(button)
            button.clicked.connect(lambda checked, b=name: self.on_button_click(b)) 

        button_layout.addSpacing(50)

        button_container = QWidget()
        button_container.setLayout(button_layout)
        button_container.setFixedHeight(self.height() // 13)
        
        menu_layout.addWidget(button_container, alignment=Qt.AlignBottom)
        menu_overlay.setLayout(menu_layout)

        central_widget = QWidget()
        stack_layout = QVBoxLayout(central_widget)
        stack_layout.addWidget(self.background_label)
        stack_layout.addWidget(menu_overlay)
        stack_layout.setContentsMargins(0, 0, 0, 0)
        
        self.setCentralWidget(central_widget)

    def on_button_click(self, button_name):
        if button_name == "EXIT":
            self.run_script("close.sh")
        elif button_name == "DOCS":
            load_docs_content(self)
        elif button_name == "LEGACY":
            self.run_script("legacy.sh")
        elif button_name == "MANUAL":
            load_man_content(self)
        elif button_name == "AUTO":
            load_automatic_content(self)


    def run_script(self, script_name):
        try:
            subprocess.run(["./" + script_name], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.warning(self, "Error", f"Failed to run {script_name}: {e}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {e}")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec_())