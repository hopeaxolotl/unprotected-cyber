#!/usr/bin/env python3
import sys
import subprocess
import os
from optmenu import load_optional_content
from servicesmenu import load_svc_content
from miscmenu import load_misc_content
from PyQt5.QtWidgets import (
    QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget, QTextEdit, QMessageBox, QHBoxLayout
)
from PyQt5.QtGui import QPixmap, QFont, QFontDatabase
from PyQt5.QtCore import QTimer, Qt

class TextDisplayWidget(QWidget):
    def __init__(self):
        super().__init__()

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("background-color: black; color: green; padding: 20px")
        self.text_edit.setFont(QFont("Courier New", 12))

        self.text_edit.setAlignment(Qt.AlignLeft)

    def update_text(self):
        if self.current_line < len(self.lines):
            self.text_edit.append(self.lines[self.current_line])
            self.current_line += 1
        else:
            self.timer.stop()

class ManWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.load_font()

        self.setWindowTitle('Unprotected Cyberscript')
        self.setFixedSize(1366, 768)

        self.text_widget = TextDisplayWidget()
        self.setCentralWidget(self.text_widget)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self.show_menu)
        self.switch_timer.setSingleShot(True)
        self.switch_timer.start(0)

    def load_font(self):
        font_path = "fonts/HelveticaNeueHeavy.otf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            print(f"Font loaded: {font_family}")
        else:
            print("Failed to load font. Please check the font path and file.")

    def show_menu(self):
        menu_widget = QWidget()

        background_label = QLabel(menu_widget)
        background_label.setPixmap(QPixmap("backgrounds/menumanual.png")) 
        background_label.setScaledContents(True)
        background_label.setGeometry(0, 0, self.width(), self.height()) 

        vbox_layout = QVBoxLayout()
        vbox_layout.setSpacing(20)
        vbox_layout.setContentsMargins(0, 0, 0, 35)
        vbox_layout.setAlignment(Qt.AlignLeft)

        button_names = [
            " (M1) Startup Procedure (Mandatory)                             ",
            "              (M1) User Administration (Users/Sudoers, Passwords, Groups)",
            " (M1) Malware and Updates (Self-explanatory)              ",
            " (M2) PAM                                                                       ",
            " (M2) SystemCtl/SystemD (Networking, Kernel)             ",
            "    ",
            " Miscellaneous Configurations                                     ",
            " Configure Services                                                      ",
            " Optional (Webmin, Lynis, Autoremove)                        ",
            " Back                                                                            ",
        ] 

        for name in button_names:
            button = QPushButton(name)
            button.clicked.connect(lambda checked, name=name: self.on_button_click(name))
            button.setFont(QFont("Helvetica Neue", 16))
            button.setStyleSheet("""
                QPushButton {
                    color: gray;
                    background: none;
                    border: none;
                    padding: 0px;
                }
                QPushButton:hover {
                    color: #f0a001; 
                }
            """)
            vbox_layout.addWidget(button)

        overlay_widget = QWidget(menu_widget)
        overlay_widget.setLayout(vbox_layout)
        overlay_widget.setGeometry(0, 0, self.width(), self.height())
        overlay_widget.setStyleSheet("background: transparent;")

        self.setCentralWidget(menu_widget)


    def on_button_click(self, button_name):
        if button_name == " (M1) Startup Procedure (Mandatory)                             ":
            self.run_script("man/startup.sh")
        elif button_name == "              (M1) User Administration (Users/Sudoers, Passwords, Groups)":
            self.run_script("man/users.sh")
        elif button_name == " (M1) Malware and Updates (Self-explanatory)              ":
            self.run_script("man/malwareupdates.sh")
        elif button_name == " (M2) PAM                                                                       ":
            self.run_script("man/pam.sh")
        elif button_name == " (M2) SystemCtl/SystemD Kernel Settings            ":
            self.run_script("man/systemctl.sh")
        elif button_name == " (M2) Networking Configuration and Surveillance             ":
            self.run_script("man/networking.sh")
        elif button_name == " Miscellaneous Configurations                                     ":
            load_misc_content(self)
        elif button_name == " Configure Services                                                      ":
            load_svc_content(self)
        elif button_name == " Optional (Webmin, Lynis, Autoremove)                        ":
            load_optional_content(self)
        elif button_name == " Back                                                                            ":
            self.run_script("back.sh")

    def run_script(self, script_name):
        try:
            subprocess.run(["./" + script_name], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.warning(self, "Error", f"Failed to run {script_name}: {e}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {e}")


def load_man_content(main_window):
    man_window = ManWindow()
    main_window.setCentralWidget(man_window)