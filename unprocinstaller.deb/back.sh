#!/bin/bash

clear
echo -e "closing programs wait 5 seconds"
pkill -f python3
python3 unprotectedcyber.py
exit
