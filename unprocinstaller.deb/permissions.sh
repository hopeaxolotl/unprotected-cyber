#!/bin/sh

clear

chmod +x "close.sh"
chmod +x "back.sh"
chmod +x "legacy.sh"

chmod +x "services/svcman.sh"
chmod +x "services/svcapache2.sh"
chmod +x "services/svcapparmor.sh"
chmod +x "services/svcauditd.sh"
chmod +x "services/svcbind9.sh"
chmod +x "services/svcmariadb.sh"
chmod +x "services/svcmysql.sh"
chmod +x "services/svcnginx.sh"
chmod +x "services/svcnullmailer.sh"
chmod +x "services/svcopenvpn.sh"
chmod +x "services/svcphp.sh"
chmod +x "services/svcproftpd.sh"
chmod +x "services/svcpostgresql.sh"
chmod +x "services/svcsamba.sh"
chmod +x "services/svcssh.sh"
chmod +x "services/svcvsftpd.sh"

chmod +x "opts/webmin.sh"
chmod +x "opts/lynis.sh"
chmod +x "opts/autoremove.sh"

chmod +x "misc/assorted.sh"
chmod +x "misc/quarantinetext.sh"
chmod +x "misc/quarantinemedia.sh"
chmod +x "misc/gnome.sh"
chmod +x "misc/lightdm.sh"
chmod +x "misc/grub.sh"
chmod +x "misc/usbs.sh"

chmod +x "manual/startup.sh"
chmod +x "manual/users.sh"
chmod +x "manual/malwareupdates.sh"
chmod +x "manual/pam.sh"
chmod +x "manual/systemctl.sh"
chmod +x "manual/networking.sh"

chmod +x "auto/auto1.sh"
chmod +x "auto/auto2.sh"

echo -e "Unprotected Cyber is now installed in your system. Invest in a condom motherfucker."

exit 0
