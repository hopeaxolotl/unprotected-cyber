#!/usr/bin/env python3
import sys
import subprocess
import os
from PyQt5.QtWidgets import (
    QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget, QTextEdit, QMessageBox, QHBoxLayout
)
from PyQt5.QtGui import QPixmap, QFont, QFontDatabase
from PyQt5.QtCore import QTimer, Qt

class TextDisplayWidget(QWidget):
    def __init__(self):
        super().__init__()

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("background-color: black; color: green; padding: 20px")
        self.text_edit.setFont(QFont("Courier New", 12))

        self.text_edit.setAlignment(Qt.AlignLeft)

    def update_text(self):
        if self.current_line < len(self.lines):
            self.text_edit.append(self.lines[self.current_line])
            self.current_line += 1
        else:
            self.timer.stop()

class DocsWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.load_font()

        self.setWindowTitle('Unprotected Cyberscript')
        self.setFixedSize(1366, 768)

        self.text_widget = TextDisplayWidget()
        self.setCentralWidget(self.text_widget)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self.show_menu)
        self.switch_timer.setSingleShot(True)
        self.switch_timer.start(0)

    def load_font(self):
        font_path = "fonts/bank gothic medium bt.ttf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            print(f"Font loaded: {font_family}")
        else:
            print("Failed to load font. Please check the font path and file.")

    def show_menu(self):
        menu_widget = QWidget()

        background_label = QLabel(menu_widget)
        background_label.setPixmap(QPixmap("backgrounds/menudocs.png")) 
        background_label.setScaledContents(True)
        background_label.setGeometry(0, 0, self.width(), self.height()) 

        vbox_layout = QVBoxLayout()
        vbox_layout.setSpacing(20)
        vbox_layout.setContentsMargins(0, 0, 0, 35)
        vbox_layout.setAlignment(Qt.AlignCenter)

        button_names = [
            "General",
            "Startup",
            "Readme",
            "Webmin",
            "Back to Main Menu",
        ]

        for name in button_names:
            button = QPushButton(name)
            button.clicked.connect(lambda checked, name=name: self.on_button_click(name))
            button.setFont(QFont("BankGothic Md BT", 30))
            button.setStyleSheet("""
                QPushButton {
                    color: #404b57;
                    background: none;
                    border: none;
                    padding: 0px;
                }
                QPushButton:hover {
                    color: #b8c8e2; 
                }
            """)
            vbox_layout.addWidget(button)

        overlay_widget = QWidget(menu_widget)
        overlay_widget.setLayout(vbox_layout)
        overlay_widget.setGeometry(0, 0, self.width(), self.height())
        overlay_widget.setStyleSheet("background: transparent;")

        self.setCentralWidget(menu_widget)


    def on_button_click(self, button_name):
        if button_name == "General":
            self.run_script("mdocs/generaldocs.sh")
        elif button_name == "Startup":
            self.run_script("mdocs/startupdocs.sh")
        elif button_name == "Readme":
            self.run_script("mdocs/readmedocs.sh")
        elif button_name == "Webmin":
            self.run_script("mdocs/webmindocs.sh")
        elif button_name == "Back to Main Menu":
            self.run_script("back.sh")

    def run_script(self, script_name):
        try:
            subprocess.run(["./" + script_name], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.warning(self, "Error", f"Failed to run {script_name}: {e}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {e}")


def load_docs_content(main_window):
    docs_window = DocsWindow()
    main_window.setCentralWidget(docs_window)