#!/bin/bash

clear
echo -e "Closing program... (wait 5 seconds)"
pkill -f python3
exit