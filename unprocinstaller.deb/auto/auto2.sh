#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt

# ------------------------------ compiler_libpam functions ------------------------------
installpamdependencies () {
    echo "${GREEN}[+] Installing PAM '${REPLY}'${RESET}"
    sudo $APT install -y libpam-cracklib fail2ban
    apt remove -y libpam-pwquality
}
passwordpolicies () {
    echo "${GREEN}[+] Configurating password policies '${REPLY}'${RESET}"
    cp /etc/pam.d/common-password backup/pam/common-password
    #
    sudo sed -i '/pam_pwquality.so/ s/^/#/' /etc/pam.d/common-password
    sudo sed -ie "s/pam_cracklib\.so.*/pam_cracklib.so retry=3 minlen=8 difok=3 dcredit=-1 ucredit=-1 lcredit=-1 ocredit=-1/" /etc/pam.d/common-password
    sudo sed -ie "s/pam_unix\.so.*/pam_unix.so obscure use_authtok try_first_pass sha512 minlen=8 remember=5/" /etc/pam.d/common-password
    sudo sed -i 's/nullok//g' /etc/pam.d/common-password
}
loginpolicies () {
    echo "${GREEN}[+] Configurating login policies '${REPLY}'${RESET}"
    cp /etc/login.defs backup/pam/login.defs
    #
    sudo sed -ie "s/PASS_MAX_DAYS.*/PASS_MAX_DAYS\\t28/" /etc/login.defs
    sudo sed -ie "s/PASS_MIN_DAYS.*/PASS_MIN_DAYS\\t7/" /etc/login.defs
    sudo sed -ie "s/PASS_WARN_AGE.*/PASS_WARN_AGE\\t7/" /etc/login.defs
    sudo sed -ie "s/FAILLOG_ENAB.*/FAILLOG_ENAB\\tyes/" /etc/login.defs
    sudo sed -ie "s/LOG_UNKFAIL_ENAB.*/LOG_UNKFAIL_ENAB\\tyes/" /etc/login.defs
    sudo sed -ie "s/LOG_OK_LOGINS.*/LOG_OK_LOGINS\\tyes/" /etc/login.defs
    sudo sed -ie "s/SYSLOG_SU_ENAB.*/SYSLOG_SU_ENAB\\tyes/" /etc/login.defs
    sudo sed -ie "s/SYSLOG_SG_ENAB.*/SYSLOG_SG_ENAB\\tyes/" /etc/login.defs
    sudo sed -ie "s/LOGIN_RETRIES.*/LOGIN_RETRIES\\t5/" /etc/login.defs
    sudo sed -ie "s/ENCRYPT_METHOD.*/ENCRYPT_METHOD\\tSHA512/" /etc/login.defs
    sudo sed -ie "s/LOGIN_TIMEOUT.*/LOGIN_TIMEOUT\\t60/" /etc/login.defs
}
accountpolicies () {
    echo "${GREEN}[+] Configurating account policies '${REPLY}'${RESET}"
    RANBEFORE=$(grep "pam_tally2.so" /etc/pam.d/common-auth)
    if [[ -z $RANBEFORE ]]
    then 
        echo "auth required pam_tally2.so deny=5 onerr=fail unlock_time=1800 audit even_deny_root silent" | sudo tee -a /etc/pam.d/common-auth > /dev/null
    fi
    
    sudo sed -i 's/nullok//g' /etc/pam.d/common-auth
}

# ------------------------------ compiler_networking functions ------------------------------
networking_sysctl_config () {
    echo "${GREEN}[+] Network Config '${REPLY}'${RESET}"
    sudo touch /etc/sysctl.d/cybercent-networking.conf

    # General IPv4 stuff updated by Liam
    echo net.ipv4.ip_forward=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.forwarding=0 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.core.bpf_jit_harden=1 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null

    # IPv4 TIME-WAIT assassination protection
    echo net.ipv4.tcp_rfc1337=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null # Scored

    # IP Spoofing protection, Source route verification  
    echo net.ipv4.conf.all.rp_filter=1      | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.rp_filter=1  | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Ignore ICMP broadcast requests
    echo net.ipv4.icmp_echo_ignore_broadcasts=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Ignore Directed pings
    echo net.ipv4.icmp_echo_ignore_all=1 | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Log Martians
    echo net.ipv4.conf.all.log_martians=1               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.icmp_ignore_bogus_error_responses=1   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Disable source packet routing
    echo net.ipv4.conf.all.accept_source_route=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.accept_source_route=0    | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.accept_source_route=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_source_route=0    | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # Block SYN attacks
    echo net.ipv4.tcp_syncookies=1          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_max_syn_backlog=2048  | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_synack_retries=2      | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.tcp_syn_retries=2         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null # Try values 1-5

    # Ignore ICMP redirects
    echo net.ipv4.conf.all.send_redirects=0         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.send_redirects=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.accept_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.accept_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.all.secure_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv4.conf.default.secure_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    echo net.ipv6.conf.all.send_redirects=0         | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.default.send_redirects=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.all.accept_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.secure_redirects=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 
    echo net.ipv6.conf.default.secure_redirects=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null 

    echo net.ipv6.conf.default.router_solicitations=0   | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_rtr_pref=0     | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_pinfo=0        | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.accept_ra_defrtr=0       | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.autoconf=0               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.dad_transmits=0          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.default.max_addresses=1          | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.all.disable_ipv6=1               | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null
    echo net.ipv6.conf.lo.disable_ipv6=1                | sudo tee -a /etc/sysctl.d/cybercent-networking.conf > /dev/null

    # sudo sysctl -p /etc/sysctl.d/cybercent.conf <--- UNCOMMENT THIS LINE!!!
    sudo sysctl --system

    echo 'blacklist ipv6' | sudo tee -a /etc/modprobe.d/blacklist > /dev/null
}

configUFW () {
    echo "${GREEN}[+] Configurating UFW/iptables '${REPLY}'${RESET}"
    sudo iptables -F
    sudo iptables -X
    sudo iptables -Z

    sudo $APT install -y ufw
    sudo ufw status verbose > backup/networking/firewall_ufw_before.log 
    echo "y" | sudo ufw reset
    sudo ufw enable 
    sudo ufw logging full

    sudo ufw default reject incoming 
    sudo ufw default allow outgoing

    sudo ufw deny 23  
    sudo ufw deny 2049  
    sudo ufw deny 515  
    sudo ufw deny 111   
    sudo ufw status verbose > backup/networking/firewall_ufw_after.log 

    # Iptables specific
    # Block null packets (DoS)
    sudo iptables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
    # Block syn-flood attacks (DoS)
    sudo iptables -A INPUT -p tcp ! --syn -m state --state NEW -j DROP
    #Drop incoming packets with fragments
    sudo iptables -A INPUT -f -j DROP
    # Block XMAS packets (DoS)
    sudo iptables -A INPUT -p tcp --tcp-flags ALL ALL -j DROP
    # Allow internal traffic on the loopback device
    sudo iptables -A INPUT -i lo -j ACCEPT
    # sudo iptables -A INPUT -p tcp -m tcp --dport 22 -j ACCEPT
    # Allow established connections
    sudo iptables -I INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
    # Allow outgoing connections
    sudo iptables -P OUTPUT ACCEPT
    # Set default deny firewall policy
    sudo iptables -P INPUT DROP
    #Block Telnet
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 23 -j DROP
    #Block NFS
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 2049 -j DROP
    #Block X-Windows
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 6000:6009 -j DROP
    #Block X-Windows font server
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 7100 -j DROP
    #Block printer port
    sudo iptables -A INPUT -p tcp -s 0/0 -d 0/0 --dport 515 -j DROP
    #Block Sun rpc/NFS
    sudo iptables -A INPUT -p udp -s 0/0 -d 0/0 --dport 111 -j DROP
    # Deny outside packets from internet which claim to be from your loopback interface.
    sudo iptables -A INPUT -p all -s localhost  -i eth0 -j DROP
    # Save rules
    sudo iptables-save > /etc/sudo iptables/rules.v4
}

log_current_processes () {
    # Full process list 
    echo "${GREEN}[+] Logging processes '${REPLY}'${RESET}"
    ps auxef > backup/misc/all_processes_`date +%s`.log
    ps auxe | grep -E "^root" > backup/misc/root_processes_`date +%s`.log 
}

monitor_ports () { 
    echo "${GREEN}[+] Logging ports '${REPLY}'${RESET}"
    # Pipes open tcp and udp ports into a less window
    sudo netstat -peltu | column -t > backup/networking/open_ports.log

    sudo $APT install nmap -y
    sudo nmap -oN backup/networking/nmap.log -p- -v localhost 
    sudo $APT purge nmap -y
}

# ------------------------------ compiler_system functions ------------------------------

file_permissions () {
    echo "${GREEN}[+] Changing like a billion file permissions for system files'${REPLY}'${RESET}"
    sudo chmod 700 "/home/$CCUSER"
    sudo chown "$CCUSER" "/home/$CCUSER"
    sudo chgrp "$CCUSER" "/home/$CCUSER"

    #compare with gtfobins.github.io (thx luka)
    sudo find / -perm /4000 #suid
    sudo find / -perm /2000 #guid
    sudo find / -perm /6000 #both

    #check file capabilities
    sudo getcap -r / 2>/dev/null
    
    #give file user/group
    find / -nouser
    find / -nogroup

    find / -type f -perm 0777

    sudo find / -type d -perm -002 ! -perm -1000
    sudo chmod +t [directory]

    #perms for gen sys files
    sudo chown root:root /etc/passwd
    sudo chmod 644 /etc/passwd
    sudo chown root:root /etc/passwd-
    sudo chmod u-x,go-wx /etc/passwd-

    sudo chown root:shadow /etc/shadow
    sudo chmod 400 /etc/shadow
    sudo chown root:shadow /etc/shadow-
    sudo chmod 400 /etc/shadow-

    sudo chown root:shadow /etc/gshadow
    sudo chmod 400 /etc/gshadow
    sudo chown root:shadow /etc/gshadow-
    sudo chmod 400 /etc/gshadow-

    sudo chown root:root /etc/group
    sudo chmod 644 /etc/group
    sudo chown root:root /etc/group-
    sudo chmod u-x,go-wx /etc/group-
    
    sudo chown root:root /etc/security/opasswd
    sudo chmod 600 /etc/security/opasswd

    sudo chown root:root /etc/sudoers
    sudo chmod 440 /etc/sudoers
    sudo chown root:root /etc/sudoers.d/*
    sudo chmod 440 /etc/sudoers.d/*

    sudo chown root:root /etc/securetty
    sudo chmod 600 /etc/securetty
    sudo chown root:root /etc/ftpusers
    sudo chmod 640 /etc/ftpusers
    sudo chown root:root /etc/inetd.conf
    sudo chmod 440 /etc/inetd.conf
    sudo chown root:root /etc/xinetd.conf
    sudo chmod 440 /etc/xinetd.conf
    sudo chown root:root /etc/inetd.d
    sudo chmod 400 /etc/inetd.d
    sudo chown root:root /etc/inetd.d/*
    sudo chmod 400 /etc/inetd.d/*
    sudo chown root:root /etc/hosts.allow
    sudo chmod 644 /etc/hosts.allow
    sudo chown root:root /etc/ers
    sudo chmod 440 /etc/ers
    sudo chown root:root /etc/fstab
    sudo chmod 644 /etc/fstab
    sudo chown root:root /boot/grub/grub.cfg
    sudo chmod 600 /boot/grub/grub.cfg

    sudo chown root:root /etc/crontab
    sudo chmod 600 /etc/crontab
    sudo chown root:root /etc/cron.hourly
    sudo chmod 600 /etc/cron.hourly
    sudo chown root:root /etc/cron.daily
    sudo chmod 600 /etc/cron.daily
    sudo chown root:root /etc/cron.weekly
    sudo chmod 600 /etc/cron.weekly
    sudo chown root:root /etc/cron.monthly
    sudo chmod 600 /etc/cron.monthly
    sudo chown root:root /etc/cron.d
    sudo chmod 600 /etc/cron.d
    sudo chown root:root /etc/cron.allow
    sudo chmod 600 /etc/cron.allow
    sudo chown root:root /etc/cron.deny
    sudo chmod 600 /etc/cron.deny

}

disable_ctrlaltdel () {
    echo "${GREEN}[+] Disabling CTRL+ALT+DEL '${REPLY}'${RESET}"
    sudo systemctl mask ctrl-alt-del.target
    echo 'exec shutdown -r now "Control-Alt-Delete pressed"' | sudo tee -a /etc/init/control-alt-delete.conf
    echo "CtrlAltDelBurstAction=none" | sudo tee -a /etc/systemd/system.conf > /dev/null
    sudo systemctl daemon-reload
}

system_sysctl_config() {
    echo "${GREEN}[+] Kernel config '${REPLY}'${RESET}"
    sudo touch /etc/sysctl.d/cybercent-system.conf

    echo kernel.dmesg_restrict=1            | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored
    echo kernel.msgmnb=65536                | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.msgmax=65536                | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.sysrq=0                     | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.maps_protect=1              | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.core_uses_pid=1             | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.shmmax=68719476736          | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.shmall=4294967296           | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.exec_shield=1               | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.panic=10                    | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.kptr_restrict=2             | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.randomize_va_space=2        | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored ASLR; 2 = full; 1 = semi; 0 = none
    echo kernel.unprivileged_userns_clone=0 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored
    echo kernel.ctrl-alt-del=0              | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Scored CTRL-ALT-DEL disable
    echo kernel.yama.ptrace_scope=2         | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo kernel.core_pattern = "/bin/false" | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo vm.panic_on_oom=1                  | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo fs.suid_dumpable=0                 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null # Core dumps # Scored
    echo fs.protected_hardlinks=1           | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo fs.protected_symlinks=1            | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null
    echo user.max_user_namespaces=0 | sudo tee -a /etc/sysctl.d/cybercent-system.conf > /dev/null

    sudo sysctl --system
}

# ------------------------------ compiler_services functions ------------------------------

configSSH () {
    echo "${GREEN}[+] Configurating services SSH '${REPLY}'${RESET}"
    # Unique config file each time
    sudo cp /etc/ssh/sshd_config backup/services/sshd_config_`date +%s`.bak

    # sshd_config 
    echo "Protocol 2" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    # echo "Port 4369"  | sudo tee -a /etc/ssh/sshd_config > /dev/null # Idk about this one chief
    
    sudo ufw allow ssh # depends on the port setting, make sure to read README about SSH ports

    echo "PermitRootLogin no"      | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitEmptyPasswords no" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "LoginGraceTime 20"       | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "X11Forwarding no"         | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "X11UseLocalhost yes"      | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "AllowTcpForwarding no"    | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "AllowAgentForwarding no"  | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "UsePAM yes"                   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "UseLogin no"                  | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PasswordAuthentication no"    | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "HostBasedAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "RhostsRSAAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PubkeyAuthentication yes"     | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "IgnoreRhosts yes"             | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "StrictModes yes"              | sudo tee -a /etc/ssh/sshd_config > /dev/null

    # echo "UsePrivilegeSeparation yes"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PrintLastLog no"              | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitUserEnvironment no"     | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "SyslogFacility AUTH"          | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "LogLevel VERBOSE" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "MaxAuthTries 3"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "MaxStartups 2"    | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "ChallengeResponseAuthentication no"   | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "KerberosAuthentication no"            | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "GSSAPIAuthentication no"              | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "UseDNS no"        | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "PermitTunnel no"  | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "ClientAliveInterval 300"  | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "ClientAliveCountMax 0"    | sudo tee -a /etc/ssh/sshd_config > /dev/null

    #---- Liams changes, edit it iyw im not very good at it
    echo "IgnoreUserKnownHosts yes" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    echo "Compression no" | sudo tee -a /etc/ssh/sshd_config > /dev/null
    

    echo 'MACs hmac-sha2-512-etm@openssh.com,hmac-sha2-256-etm@openssh.com,hmac-sha2-512,hmac-sha2-256' | sudo tee -a /etc/ssh/sshd_config > /dev/null

    echo "Banner /etc/issue.net" | sudo tee -a /etc/ssh/sshd_config > /dev/null

    # New welcome banner
    echo "Alexander Boris de Pfeffel Johnson Nicholas \"Harperina\" Owenson is gay" | sudo tee /etc/issue.net > /dev/null

    GOODSYNTAX=$(sudo sshd -t)
    if [[ ! -z $GOODSYNTAX ]]
    then
        echo "${RED}Sshd config has some faults, please check script or ${BOLD}/etc/ssh/sshd_config${RESET}"
        read -rp ""
    fi

    # File permissions
    sudo chown root /etc/ssh/sshd_config
    sudo chgrp root /etc/ssh/sshd_config
    sudo chmod 600 /etc/ssh/sshd_config

    sudo service ssh restart
}
configVSFTPD () {
    echo "${GREEN}[+] Configurating services VSFTPD '${REPLY}'${RESET}"
    # Unique config file each time
    local config_file="/etc/vsftpd.conf"
    if [[ ! -f $config_file ]]
    then 
        config_file="/etc/vsftpd/vsftpd.conf"
    fi 

    sudo cp $config_file backup/services/vsftpd_conf_`date +%s`.bak

    sudo ufw allow ftp 
    sudo ufw allow 20

    # vsftpd.conf

    # Jail users to home directory (user will need a home dir to exist)
    echo "chroot_local_user=YES"                        | sudo tee $config_file > /dev/null
    echo "chroot_list_enable=YES"                       | sudo tee -a $config_file > /dev/null
    echo "chroot_list_file=/etc/vsftpd.chroot_list"     | sudo tee -a $config_file > /dev/null
    echo "allow_writeable_chroot=YES"                   | sudo tee -a $config_file > /dev/null # Only enable if you want files to be editable

    # Allow or deny users
    echo "userlist_enable=YES"                  | sudo tee -a $config_file > /dev/null
    echo "userlist_file=/etc/vsftpd.userlist"   | sudo tee -a $config_file > /dev/null
    echo "userlist_deny=NO"                     | sudo tee -a $config_file > /dev/null

    # General config
    echo "anonymous_enable=NO"          | sudo tee -a $config_file > /dev/null # disable  anonymous login
    echo "local_enable=YES"             | sudo tee -a $config_file > /dev/null # permit local logins
    echo "write_enable=YES"             | sudo tee -a $config_file > /dev/null # enable FTP commands which change the filesystem
    echo "local_umask=022"              | sudo tee -a $config_file > /dev/null # value of umask for file creation for local users
    echo "dirmessage_enable=YES"        | sudo tee -a $config_file > /dev/null # enable showing of messages when users first enter a new directory
    echo "xferlog_enable=YES"           | sudo tee -a $config_file > /dev/null # a log file will be maintained detailing uploads and downloads
    echo "connect_from_port_20=YES"     | sudo tee -a $config_file > /dev/null # use port 20 (ftp-data) on the server machine for PORT style connections
    echo "xferlog_std_format=YES"       | sudo tee -a $config_file > /dev/null # keep standard log file format
    echo "listen=NO"                    | sudo tee -a $config_file > /dev/null # prevent vsftpd from running in standalone mode
    echo "listen_ipv6=YES"              | sudo tee -a $config_file > /dev/null # vsftpd will listen on an IPv6 socket instead of an IPv4 one
    echo "pam_service_name=vsftpd"      | sudo tee -a $config_file > /dev/null # name of the PAM service vsftpd will use
    echo "userlist_enable=YES"          | sudo tee -a $config_file > /dev/null # enable vsftpd to load a list of usernames
    echo "tcp_wrappers=YES"             | sudo tee -a $config_file > /dev/null # turn on tcp wrappers
    echo "ssl_enable=YES"		        | sudo tee -a $config_file > /dev/null # Enables logging in with SSL, risky (but is scored)

    echo "ascii_upload_enable=NO"   | sudo tee -a $config_file > /dev/null 
    echo "ascii_download_enable=NO" | sudo tee -a $config_file > /dev/null 

    sudo service vsftpd restart 
}

configPUREFTPD () {
    echo "${GREEN}[+] Configurating services PUREFTPD '${REPLY}'${RESET}"

    sudo cp /etc/pure-ftpd/pure-ftpd.conf backup/services/pure-ftpd_conf_`date +%s`.bak
    # Unique config file each time
    sudo ufw allow ftp 
    sudo ufw allow 20

    # pure-ftpd.conf

    echo "ChrootEveryone yes"           | sudo tee /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "NoAnonymous yes"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousOnly no"             | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousCanCreateDirs no"    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AnonymousCantUpload yes"      | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AllowUserFXP no"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AllowAnonymousFXP no"         | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "DisplayDotFiles yes"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "ProhibitDotFilesWrite yes"    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "ProhibitDotFilesRead no"      | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "DontResolve yes"              | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "VerboseLog yes"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "SyslogFacility ftp"           | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "PAMAuthenticate yes"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "UnixAuthenticate no"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "MaxClientsNumber 50"          | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "LimitRecursion 500 8"         | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxClientsPerIp 3"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxIdleTime 10"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "MaxLoad 4"                    | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "IPV4Only yes"                 | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "TLS 2"                        | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "Umask 133:022"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    echo "Daemonize yes"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "NoChmod yes"                  | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    # echo "KeepAllFiles yes"             | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "CreateHomeDir yes"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AutoRename yes"               | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "AntiWarez yes"                | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null
    echo "CustomerProof yes"            | sudo tee -a /etc/pure-ftpd/pure-ftpd.conf > /dev/null

    sudo service pure-ftpd restart 
}

configSAMBA() {
    echo "${GREEN}[+] Configurating services SAMBA '${REPLY}'${RESET}"
    # Unique config file each time
    sudo cp /etc/samba/smb.conf backup/services/smb_conf_`date +%s`.bak

    sudo ufw allow samba

    # smb.conf 
    echo "restrict anonymous = 2"       | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "encrypt passwords = yes"      | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "read only = yes"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "ntlm auth = no"               | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "obey pam restrictions = yes"  | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "server signing = mandatory"   | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "smb encrypt = mandatory"      | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "min protocol = SMB2"          | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "protocol = SMB2"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "guest ok = no"                | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "max log size = 24"            | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "disable netbios = yes"        | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "smb ports = 445"              | sudo tee -a /etc/samba/smb.conf > /dev/null
    echo "printcap name = /dev/null"    | sudo tee -a /etc/samba/smb.conf > /dev/null


    echo "${YELLOW}Please read the samba file ${BOLD}/etc/samba/smb.conf${RESET}${YELLOW} as well and check its contents${RESET}"

    sudo systemctl restart smbd && sleep 3 && sudo systemctl status smbd
    sudo smbpasswd -a "$CCUSER"
}

configAUDITD () {
   echo "${GREEN}[+] Configurating services AUDITD '${REPLY}'${RESET}"
    echo "--loginuid-immutable" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "-b 1024" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "-e 2" | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "write_logs = yes" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_file = /var/log/audit/audit.log" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_group = root" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "log_format = ENRICHED"  | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "admin_space_left = 50" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "admin_space_left_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "space_left_action = email" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "action_mail_acct = root" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "space_left = 250000" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "disk_full_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "disk_error_action = HALT" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "local_events = yes" | sudo tee -a /etc/audit/auditd.conf > /dev/null
    echo "max_log_file_action = rotate" | sudo tee -a /etc/audit/auditd.conf > /dev/null

    echo "
	# First rule - delete all
	-D
	#Ensure events that modify date and time information are collected
	-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change
	-a always,exit -F arch=b64 -S clock_settime -k time-change
	-a always,exit -F arch=b32 -S clock_settime -k time-change
	-w /etc/localtime -p wa -k time-change
	#Ensure events that modify user/group information are collected
	-w /etc/group -p wa -k identity
	-w /etc/passwd -p wa -k identity
	-w /etc/gshadow -p wa -k identity
	-w /etc/shadow -p wa -k identity
	-w /etc/security/opasswd -p wa -k identity
	#Ensure events that modify the system's network environment are collected
	-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale
	-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale
	-w /etc/issue -p wa -k system-locale
	-w /etc/issue.net -p wa -k system-locale
	-w /etc/hosts -p wa -k system-locale
	-w /etc/network -p wa -k system-locale
	-w /etc/networks -p wa -k system-locale
	#Ensure events that modify system's MAC are collected
	-w /etc/apparmor/ -p wa -k MAC-policy
	-w /etc/apparmor.d/ -p wa -k MAC-policy
	#Ensure login and logouts events are collected
	-w /var/log/faillog -p wa -k logins
	-w /var/log/lastlog -p wa -k logins
	-w /var/log/tallylog -p wa -k logins
	#Ensure session initiation information is collected
	-w /var/run/utmp -p wa -k session
	-w /var/run/wtmp -p wa -k session
	-w /var/run/btmp -p wa -k session
	#Ensure discretionary access control permission modification events are collected
	-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
	-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod
	#Ensure unsuccessful unauthorized file access attempts are collected
	-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EACCES -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b64 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access
	-a always,exit -F arch=b32 -S creat -S open -S openat -S truncate -S ftruncate -F exit=-EPERM -F auid>=1000 -F auid!=4294967295 -k access
	#Ensure successful file system mounts are collected
	-a always,exit -F arch=b64 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
	-a always,exit -F arch=b32 -S mount -F auid>=1000 -F auid!=4294967295 -k mounts
	#Ensure file deletion events by users are collected
	-a always,exit -F arch=b64 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
	-a always,exit -F arch=b32 -S unlink -S unlinkat -S rename -S renameat -F auid>=1000 -F auid!=4294967295 -k delete
	#Ensure changes to system administration scope (ers) is collected
	-w /etc/ers -p wa -k scope
	-w /etc/ers.d -p wa -k scope
	#Ensure system administrator actions (log) are collected
	-w /var/log/.log -p wa -k actions
	#Ensure kernel module loading and unloading is collected
	-w /sbin/insmod -p x -k modules
	-w /sbin/rmmod -p x -k modules
	-w /sbin/modprobe -p x -k modules
	-a always,exit -F arch=b64 -S init_module -S delete_module -k modules
	# increase the buffers to survive stress events. make this bigger for busy systems.
	-b 1024
	# monitor unlink() and rmdir() system calls.
	-a exit,always -S unlink -S rmdir
	# monitor open() system call by Linux UID 1001.
	-a exit,always -S open -F loginuid=1001
	" | sudo tee -a /etc/audit/audit.rules > /dev/null

    sudo systemctl restart auditd.service && sudo augenrules --load && sudo auditctl -l

}

configAPACHE2 () {
    echo "${GREEN}[+] Configurating services APACHE2 '${REPLY}'${RESET}"
    sudo cp /etc/apache2/apache2.conf backup/services/apache2_conf_`date +%s`.bak
    sudo cp /etc/apache2/conf-available/security.conf backup/services/apache2_security_conf_`date +%s`.bak

    sudo ufw allow apache
    sudo ufw allow https 
    sudo ufw allow http

    local answer=""
    echo -n "${CYAN}Remove default index.html [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo "" | sudo tee /var/www/html/index.html
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo "HostnameLookups Off"              | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "LogLevel warn"                    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "ServerTokens Prod"                | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "ServerSignature Off"              | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Options all -Indexes"             | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Header unset ETag"                | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Header always unset X-Powered-By" | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "FileETag None"                    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "TraceEnable off"                  | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "Timeout 60"                       | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    
    echo "RewriteEngine On"                         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo 'RewriteCond %{THE_REQUEST} !HTTP/1\.1$'   | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo 'RewriteRule .* - [F]'                     | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    echo '<IfModule mod_headers.c>'                         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo '    Header set X-XSS-Protection 1;'               | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo '</IfModule>'                                      | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    # Secure /
    echo "<Directory />"            | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options -Indexes"     | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    AllowOverride None"   | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Order Deny,Allow"     | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options None"         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Deny from all"        | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "</Directory>"             | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    
    # Secure /var/www/html
    echo "<Directory /var/www/html>"    | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "    Options -Indexes"         | sudo tee -a /etc/apache2/apache2.conf > /dev/null
    echo "</Directory>"                 | sudo tee -a /etc/apache2/apache2.conf > /dev/null

    # security.conf
    # Enable HTTPOnly and Secure Flags
    echo 'Header edit Set-Cookie ^(.*)\$ \$1;HttpOnly;Secure'                                   | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Clickjacking Attack Protection
    echo 'Header always append X-Frame-Options SAMEORIGIN'                                      | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # XSS Protection
    echo 'Header set X-XSS-Protection "1; mode=block"'                                          | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Enforce secure connections to the server
    echo 'Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"'    | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null  

    # MIME sniffing Protection
    echo 'Header set X-Content-Type-Options: "nosniff"'                                         | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Prevent Cross-site scripting and injections
    echo 'Header set Content-Security-Policy "default-src '"'self'"';"'                         | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

	# Secure root directory
    echo "<Directory />"            | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Options -Indexes"       | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  AllowOverride None"     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Order Deny,Allow"       | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Deny from all"          | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "</Directory>"             | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    # Secure html directory
    echo "<Directory /var/www/html>"        | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Options -Indexes -Includes"     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  AllowOverride None"             | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Order Allow,Deny"               | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "  Allow from All"                 | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null
    echo "</Directory>"                     | sudo tee -a /etc/apache2/conf-available/security.conf > /dev/null

    #ports.conf
    echo "Listen 80" | sudo tee -a /etc/apache2/ports.conf
    echo "    Listen 443" | sudo tee -a /etc/apache2/ports.conf
    echo "</IfModule>" | sudo tee -a /etc/apache2/ports.conf
    echo "<IfModule mod_gnutls.c>" | sudo tee -a /etc/apache2/ports.conf
    echo "    Listen 443" | sudo tee -a /etc/apache2/ports.conf
    echo "</IfModule>" | sudo tee - a /etc/apache2/ports.conf

    #some other cmds i found, its in apache2.json but idk what it is so id just leave it in unless YOU KNOW WHAT IT IS BRODIE!!
    sudo apt install libapache2-mod-security2
    cp /etc/modsecurity/modsecurity.conf-recommended /etc/modsecurity/modsecurity.conf
    sudo nano /etc/modsecurity/modsecurity.conf
    LoadModule evasive20_module modules/mod_evasive24.so
    LoadModule security2_module modules/mod_security2.so
 
    # ssl.conf
    # TLS only
    sudo sed -i "s/SSLProtocol.*/SSLProtocol –ALL +TLSv1 +TLSv1.1 +TLSv1.2/" /etc/apache2/mods-available/ssl.conf
    # Stronger cipher suite
    sudo sed -i "s/SSLCipherSuite.*/SSLCipherSuite HIGH:\!MEDIUM:\!aNULL:\!MD5:\!RC4/" /etc/apache2/mods-available/ssl.conf

    sudo chown -R root:root /etc/apache2
    sudo chown -R root:root /etc/apache 2> /dev/null

    sudo service apache2 restart && sleep 3 && sudo service apache2 status
}

configOPENVPN () {
    echo "${GREEN}[+] Configurating services OPENVPN '${REPLY}'${RESET}"
    wget https://git.io/vpn -O openvpn-install.sh
    sudo chmod 700 openvpn-install.sh
    sudo ./openvpn-install.sh

    echo "tls-crypt ta.key 0" | sudo tee -a /etc/openvpn/server/server.conf
    echo "user nobody" | sudo tee -a /etc/openvpn/server/server.conf
    echo "group nobody" | sudo tee -a /etc/openvpn/server/server.conf
    echo "persist-key" | sudo tee -a /etc/openvpn/server/server.conf
    echo "persist-tun" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "cipher AES-256-CBC" | sudo tee -a /etc/openvpn/server/server.conf
    echo "ncp-disable" | sudo tee -a /etc/openvpn/server/server.conf
    echo "6543" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "opt-verify" | sudo tee -a /etc/openvpn/server/server.conf
    echo "keepalive 10 60" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "sudo vi /etc/sysctl.d/" | sudo tee -a /etc/openvpn/server/server.conf
    echo "net.ipv4.ip_forward=1" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "plugin /usr/share/openvpn/plugin/lib/openvpn-auth-pam.so /etc/pam.d/login" | sudo tee -a /etc/openvpn/server/server.conf
    echo "auth-gen-token 43200" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "dh none" | sudo tee -a /etc/openvpn/server/server.conf
    echo "ecdh-curve secp384r1" | sudo tee -a /etc/openvpn/server/server.conf
    echo "tls-server" | sudo tee -a /etc/openvpn/server/server.conf
    
    echo "auth SHA512" | sudo tee -a /etc/openvpn/server/server.conf
    echo "max-clients 12" | sudo tee -a /etc/openvpn/server/server.conf
    
    service openvpn restart
}

configAPPARMOR () {
    echo "${GREEN}[+] Configurating services APPARMOR '${REPLY}'${RESET}"
    sudo apt install apparmor apparmor-profiles apparmor-utils
    sudo systemctl enable apparmor && sudo systemctl start apparmor.service && sudo update-rc.d apparmor defaults
    sudo apparmor_status
    #Review profiles, making note of dodgy ones, and those that are disabled, but ought not to be"],
    cd /etc/apparmor.d/ && ls,
    #"To list all profiles (including those that are disabled, for instance):",
    find -type d | xargs ls
    #"To disable a profile:",
    sudo ln -s /etc/apparmor.d/{PROFILE.NAME} /etc/apparmor.d/disable/ && sudo apparmor_parser -R /etc/apparmor.d/{PROFILE.NAME}

    sudo systemctl reload apparmor.service

    sudo aa-enforce /etc/apparmor.d/*
    sudo apparmor_status
    sudo rm /etc/apparmor.d/disable/usr.bin.firefox
    sudo apparmor_parser /etc/apparmor.d/usr.bin.firefox
    echo 'GRUB_CMDLINE_LINUX_DEFAULT=\"$GRUB_CMDLINE_LINUX_DEFAULT apparmor=1 security=apparmor\"' | sudo tee -a /etc/grub.d/40-apparmor
    sudo update-grub
    sudo reboot
}

configMARIADB () {
    echo "${GREEN}[+] Configurating services MARIADB/SQL '${REPLY}'${RESET}"
    sudo apt install mariadb-server
    sudo mysql_secure_installation

    local sslmdb=""
    echo -n "${CYAN} Complete SSL? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $sslmdb in 
        y|Y)
            echo "ssl=on" | sudo tee -a /etc/mysql/my.cnf > /dev/null
            cd /etc/mysql && sudo mkdir ssl && cd ssl
            sudo openssl genrsa 4096 > ca-key.pem
            sudo openssl req -new -x509 -nodes -days 365000 -key ca-key.pem -out ca-cert.pem
            sudo openssl req -newkey rsa:2048 -days 365000 -nodes -keyout server-key.pem -out server-req.pem
            sudo openssl rsa -in server-key.pem -out server-key.pem
            sudo openssl x509 -req -in server-req.pem -days 365000 -CA ca-cert.pem -CAkey ca-key.pem -set_serial 01 -out server-cert.pem
            sudo openssl req -newkey rsa:2048 -days 365000 -nodes -keyout client-key.pem -out client-req.pem
            sudo openssl rsa -in client-key.pem -out client-key.pem
            sudo openssl x509 -req -in client-req.pem -days 365000 -CA ca-cert.pem -CAkey ca-key.pem -set_serial 01 -out client-cert.pem
            sudo openssl verify -CAfile ca-cert.pem server-cert.pem client-cert.pem
            ;;
        n|N)
            echo "felix is gay placeholder"
            ;;
    esac

    sudo chown root:root /etc/mysql/my.cnf
    sudo chmod 644 /etc/mysql/my.cnf
    sudo chown mysql:mysql /var/lib/mysql
    sudo chmod 755 /var/lib/mysql
    
    echo -e "[mysqld]\nbind-address = 127.0.0.1\nssl-ca=/etc/mysql/ssl/ca-cert.pem\nssl-cert=/etc/mysql/ssl/server-cert.pem\nssl-key=/etc/mysql/ssl/server-key.pem\ntls_version = TLSv1.2,TLSv1.3" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "local-infile=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "port = 13306" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "log-error=/var/log/mariadb/mariadb.log" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connect_errors = 3" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "skip-show-database" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "symbolic-links = 0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "default_password_lifetime = 90" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "key_buffer_size = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_allowed_packet = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connections = 2" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo -e "[client]\nssl-ca=/etc/mysql/ssl/ca-cert.pem\nssl-cert=/etc/mysql/ssl/client-cert.pem\nssl-key=/etc/mysql/ssl/client-key.pem\ntls_version = TLSv1.2,TLSv1.3" | sudo tee -a /etc/mysql/my.cnf > /dev/null

    sudo chown -Rv mysql:root /etc/mysql/ssl/
    sudo service mysql restart
}

configMYSQL () {
    echo "${GREEN}[+] Configurating services MYSQL '${REPLY}'${RESET}"
    sudo ufw allow mysql 
    sudo apt install mysql-server
    sudo sysyemctl enable mysql
    sudo mysql_secure_installation

    local sslmsql=""
    echo -n "${CYAN} Complete SSL? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $sslmsql in 
        y|Y)
            echo "ssl=on" | sudo tee -a /etc/mysql/my.cnf > /dev/null
            sudo mkdir -p /etc/certs
            sudo cd /etc/certs
            sudo openssl genrsa 2048 > ca-key.pem
            sudo openssl req -new -x509 -nodes -days 3600 -key ca-key.pem -out ca.pem
            sudo openssl req -newkey rsa:2048 -days 3600 -nodes -keyout server-key.pem -out server-req.pem
            sudo openssl rsa -in server-key.pem -out server-key.pem
            sudo penssl x509 -req -in server-req.pem -days 3600 -CA ca.pem -CAkey ca-key.pem -set_serial 01 -out server-cert.pem
            sudo openssl req -newkey rsa:2048 -days 3600 -nodes -keyout client-key.pem -out client-req.pem
            sudo openssl rsa -in client-key.pem -out client-key.pem
            sudo openssl x509 -req -in client-req.pem -days 3600 -CA ca.pem -CAkey ca-key.pem -set_serial 01 -out client-cert.pem
            sudo openssl verify -CAfile ca.pem server-cert.pem client-cert.pem
            ;;
        n|N)
            echo "felix is gay placeholder"
            ;;
    esac

    sudo chown root:root /etc/mysql/my.cnf
    sudo chmod 644 /etc/mysql/my.cnf
    sudo chown mysql:mysql /var/lib/mysql
    sudo chmod 755 /var/lib/mysql

    sudo rm -rf ~/.mysql_history

    echo "local-infile=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "log_error=/var/log/mysql/error.log" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "skip-show-database" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "bind-address=127.0.0.1" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "symbolic-links=0" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "default_password_lifetime = 90" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "key_buffer_size         = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_allowed_packet      = 16M" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "max_connections = 20" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "[mysqld]" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "user = sqlroot" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "password = Fus1()n123" | sudo tee -a /etc/mysql/my.cnf > /dev/null
    echo "port=3360" | sudo tee -a /etc/mysql/my.cnf > /dev/null

    sudo chown -R mysql:mysql /etc/certs/
    sudo chmod 600 client-key.pem server-key.pem ca-key.pem

    sudo service mysql restart
    sudo service mysqld restart
}

configPHP () {
    echo "${GREEN}[+] Configurating services PHP '${REPLY}'${RESET}"
    sudo apt install php libapache2-mod-php
    sudo apt install php-mysql

    # config wall
    echo "sql.safe_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "safe_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "safe_mode_gid = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "magic_quotes_gpc = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "register_globals = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "track_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "html_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "expose_php = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "mail.add_x_header = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_url_fopen = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_url_include = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "file_uploads = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "post_max_size = 1K" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "upload_max_filesize = 2M" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_input_vars = 100" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_cookies = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_secure = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_only_cookies = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_httponly = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_lifetime = 14400" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cookie_samesite = Strict" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.cache_expire = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.use_strict_mode = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "enable_dl = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "disable_functions = ini_set,php_uname,getmyuid,getmypid,passthru,leak,listen,diskfreespace,tmpfile,link,ignore_user_abord,shell_exec,dl,set_time_limit,exec,system,highlight_file,source,show_source,fpaththru,virtual,posix_ctermid,posix_getcwd,posix_getegid,posix_geteuid,posix_getgid,posix_getgrgid,posix_getgrnam,posix_getgroups,posix_getlogin,posix_getpgid,posix_getpgrp,posix_getpid,posix,_getppid,posix_getpwnam,posix_getpwuid,posix_getrlimit,posix_getsid,posix_getuid,posix_isatty,posix_kill,posix_mkfifo,posix_setegid,posix_seteuid,posix_setgid,posix_setpgid,posix_setsid,posix_setuid,posix_times,posix_ttyname,posix_uname,proc_open,proc_close, proc_get_status,proc_nice,proc_terminate,phpinfo,popen,curl_exec,curl_multi_exec,parse_ini_file,allow_url_fopen,allow_url_include,pcntl_exec,chgrp,chmod,chown,lchgrp,lchown,putenv" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_execution_time = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "max_input_time = 30" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "memory_limit = 8M" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "report_memleaks = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "display_startup_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "error_reporting = E_ALL" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "log_errors = On" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "error_log = /var/log/php-scripts.log" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "ignore_repeated_errors = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "output_buffering = 4096" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "register_argc_argv = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "request_order = \"GP\"" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "variables_order = \"GPCS\"" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "allow_webdav_methods = Off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.gc_maxlifetime = 600" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "short_open_tag=off" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "cgi.force_redirect = 1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "cgi.discard_path=1" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.bug_compat_42 = 0" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null
    echo "session.bug_compat_warn = 0" | sudo tee -a /etc/php/8.1/cli/php.ini > /dev/null

    service restart php
    service restart apache2
}

configPROFTPD () {
    echo "${GREEN}[+] Configurating services PROFTPD '${REPLY}'${RESET}"
    sudo ufw allow ftp 
    sudo ufw allow 20
    
    #ready for a config wall guys
    echo "Deny Filter \\*.*/" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "DelayEngine on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseLastLog on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "SetLastLog on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "IdentLookups off" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSEngine on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSProtocol SSLv23" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseReverseDNS on" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "UseIPv6 off" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxInstances 10" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxClients 10" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "MaxLoginAttempts 10 'Maximum number of allowed users are already connected (%m)" | sudo tee -a /etc/proftpd/proftpd.conf
    echo "AllowFilter \"^[a-zA-Z0-9 ,]*$\"" | sudo tee -a /etc/proftpd/proftpd.conf

    echo "TLSEngine on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSProtocol SSLv23" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSLog /var/log/proftpd/tls.log" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSRequired on" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSVerifyClient off" | sudo tee -a /etc/proftpd/tls.conf
    echo "TLSOptions dNSNameRequired iPAddressRequired" | sudo tee -a /etc/proftpd/tls.conf

    sudo service restart proftpd
}

configENUM () {
    echo "${GREEN}[+] Disabling a bunch of stuff not needed yet '${REPLY}'${RESET}"
    #this is it i promise
    sudo systemctl disable snmpd
    sudo systemctl disable avahi-daemon
    sudo systemctl disable cups
    sudo systemctl disable cups-browsed
    sudo systemctl disable cupsd
    sudo systemctl disable isc-dhcp-server
    sudo systemctl disable isc-dhcp-server6
    sudo systemctl disabled slapd
    sudo systemctl disable autofs
    sudo systemctl disable nfs-server
    sudo systemctl disable nfs-kernel-server
    sudo systemctl disable rpcbind
    sudo systemctl disable squid
    sudo systemctl disable rsync
    sudo systemctl disable nis
    sudo systemctl disable tftpd-hpa
    sudo systemctl disable debug-shell
    sudo systemctl disable bluetooth
    sudo systemctl disable kdump
    sudo systemctl disable debug-shell.service
    
    sudo systemctl disable pop3
    sudo systemctl disable imap 
    sudo systemctl disable icmp 
    sudo systemctl disable sendmail
    sudo systemctl disable smbd
    sudo systemctl disable samba-ad-dc
    sudo systemctl disable nginx
    sudo systemctl disable apache2
    sudo systemctl disable mysql
    sudo systemctl disable ssh
    sudo systemctl disable vsftpd
    sudo systemctl disable pure-ftpd
    sudo systemctl disable proftp

    sudo systemctl disable bind9               
    sudo systemctl disable dovecot
        
    $APT purge -y xserver-xorg*
    $APT purge -y openbsd-inetd
    $APT purge -y ldap-utils 
    $APT purge -y nis
    $APT purge -y talk
    $APT purge -y telnet # Scored
}

configNULLMAILER () {
    echo "${GREEN}[+] Configurating services NULLMAILER '${REPLY}'${RESET}"
    sudo apt install nullmailer aide
    sudo aide --init

    echo "/sbin/auditctl p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/auditd p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/ausearch p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/aureport p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/autrace p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/audispd p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null
    echo "/sbin/augenrules p+i+n+u+g+s+b+acl+xattrs+sha512" | sudo tee -a  /etc/aide/conf > /dev/null

    echo "SILENTREPORTS=no" | sudo tee -a /etc/default/aide > /dev/null
}
    
configCRON () {
    echo "${GREEN}[+] Configurating CRONTABS '${REPLY}'${RESET}"
    local normal_crontab='# /etc/crontab: system-wide crontab\n
    # Unlike any other crontab you dont have to run the crontab\n
    # command to install the new version when you edit this file\n
    # and files in /etc/cron.d. These files also have username fields,\n
    # that none of the other crontabs do.\n

    SHELL=/bin/sh\n
    PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin\n

    # m h dom mon dow user  command\n
    17 \*    \* \* \*   root    cd / && run-parts --report /etc/cron.hourly\n
    25 6    \* \* \*   root    test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.daily )\n
    47 6    \* \* 7   root    test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.weekly )\n
    52 6    1 \* \*   root    test -x /usr/sbin/anacron || ( cd / && run-parts --report /etc/cron.monthly )\n
    #'
    
    # Save a backup of the crontab and then just replace it with an empty one
    sudo cp /etc/crontab backup/services/crons/crontab
    echo -e $normal_crontab | sed "s/^ //g; s/\\\*//g" | sudo tee /etc/crontab > /dev/null

    # List all the crontabs 
    #sudo ls -la /var/spool/cron/* 2> /dev/null | tee backup/services/crontabs_
    sudo ls -la /etc/cron.d/* 2> /dev/null      | tee backup/services/crons/crontab_system_crons.log > /dev/null
    sudo ls -la /etc/cron.hourly/ 2> /dev/null  | tee -a backup/services/crons/crontab_system_crons.log > /dev/null
    sudo ls -la /etc/cron.daily/* 2> /dev/null  | tee -a backup/services/crons/crontab_system_crons.log  > /dev/null
    sudo ls -la /etc/cron.weekly/* 2> /dev/null | tee -a backup/services/crons/crontab_system_crons.log > /dev/null
    sudo ls -la /etc/cron.monthly/* 2> /dev/null| tee -a backup/services/crons/crontab_system_crons.log > /dev/null

    local user_crons=$(sudo ls /var/spool/cron/crontabs)
    local answer=""
    if [[ ! -z $user_crons ]]
    then 
        echo "${YELLOW}[!] Detected user crontabs at /var/spool/cron/crontabs for users: ${user_crons}${RESET}"
        echo -n "${CYAN}Move user crontabs to quarantine [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
        read -rp "" answer
        case $answer in 
            y|Y)
                echo
                echo "${GREEN}[*] Crontabs moved to backup/services/crons/ ${RESET}"
                for cron in $user_crons
                do 
                    sudo mv /var/spool/cron/crontabs/$cron backup/services/crons/$cron
                done 
                ;;
            n|N)
                ;; 
        esac
    fi
}

configBIND9 () {
    echo "${GREEN}[+] Configurating services BIND9 '${REPLY}'${RESET}"
    sudo apt install bind9 bind9utils.

    echo "OPTIONS=\"-u bind -4\"" | sudo tee -a /etc/default/bind9 < /dev/null

    echo "include \"/etc/bind/named.conf.options\";" | sudo tee -a /etc/bind/named.conf < /dev/null
    echo "include \"/etc/bind/named.conf.local\";" | sudo tee -a /etc/bind/named.conf < /dev/null
    echo "include \"/etc/bind/named.conf.default-zones\";" | sudo tee -a /etc/bind/named.conf < /dev/null

    echo "acl \"trusted\" { [local ip]; };" | sudo tee -a /etc/bind/named.conf.options
    echo "recursion no;" | sudo tee -a /etc/bind/named.conf.options
    echo "allow-recursion { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "listen-on { [local ip]; };" | sudo tee -a /etc/bind/named.conf.options
    echo "allow-transfer { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "forwarders { 8.8.8.8; 8.8.4.4; };" | sudo tee -a /etc/bind/named.conf.options
    echo "dnssec-validation yes;" | sudo tee -a /etc/bind/named.conf.options
    echo "auth-nxdomain no;" | sudo tee -a /etc/bind/named.conf.options
    echo "listen-on-v6 { none; };" | sudo tee -a /etc/bind/named.conf.options
    echo "server-id none;" | sudo tee -a /etc/bind/named.conf.options
    echo "version none;" | sudo tee -a /etc/bind/named.conf.options

    echo "zone \"mydomain.com\" {" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  type master;" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  file \"/etc/bind/zones/db.mydomain.com\";" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "  allow-transfer { none; };" | sudo tee -a /etc/bind/named.conf.local > /dev/null
    echo "};" | sudo tee -a /etc/bind/named.conf.local > /dev/null

    sudo systemctl restart bind9 && sudo systemctl status bind9
}

configNGINX () {
    echo "${GREEN}[+] Configurating services NGINX '${REPLY}'${RESET}"
    #config nginx wall hahaahahfdsgjl;kf
    echo "return 301 https://$server_name$request_uri;" | sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "limit_conn addr 1;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_req zone=one;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_req_zone $binary_remote_addr zone=one:10m rate=30r/m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "limit_conn_zone $binary_remote_addr zone=addr:10m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "add_header Set-Cookie \"Path=/; HttpOnly; Secure\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Frame-Options \"DENY\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-XSS-Protection \"1; mode=block\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Strict-Transport-Security \"max-age=31536000; includeSubDomains; preload\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Content-Type-Options: \"nosniff\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header X-Robots-Tag none;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Content-Security-Policy \"default-src 'self';\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Referrer-Policy: \"strict-origin-when-cross-origin\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Content-Type: \"text/html; charset=UTF-8\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Access-Control-Allow-Origin: \"https://MyWebsiteDomain.com\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Opener-Policy: \"same-origin\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Resource-Policy: \"same-site\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "add_header Cross-Origin-Embedder-Policy: \"require-corp\";"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "server_tokens off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "etag off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    #SSL - Super Shitty Lines
    echo "ssl_prefer_server_ciphers on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_protocols TLSv1.2 TLSv1.3;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-SHA384;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_session_timeout 5m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_session_cache shared:SSL:10m;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_certificate /etc/ssl/certs/nginx-selfsigned.crt;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_certificate_key /etc/ssl/private/nginx-selfsigned.key;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "ssl_dhparam /etc/ssl/certs/dhparam.pem;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    sudo mkdir /etc/ssl/private
    sudo chmod 700 /etc/ssl/private
    sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /etc/ssl/private/nginx-selfsigned.key -out /etc/ssl/certs/nginx-selfsigned.crt
    sudo openssl dhparam -out /etc/ssl/certs/dhparam.pem 2048

    echo "client_body_buffer_size  1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "client_header_buffer_size 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "client_max_body_size 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "large_client_header_buffers 2 1k;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "gzip off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "sendfile on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "tcp_nopush off;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "tcp_nodelay on;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "keepalive_timeout 65;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "types_hash_max_size 2048;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    echo "access_log /var/log/access.log combined;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null
    echo "error_log /var/log/warn.log warn;"| sudo tee -a /etc/nginx/sites-enabled/default > /dev/null

    sudo service nginx restart && sleep 3 && sudo service nginx status

}

configPOSTGRESQL () {
    echo "${GREEN}[+] Configurating services POSTGRESQL '${REPLY}'${RESET}"
    echo "ssl = on" | sudo tee -a /etc/postgresql/12/main/postgresql.conf > /dev/null
}

installPSPY () { 
    echo "${GREEN}[+] Configurating services PSPY '${REPLY}'${RESET}"
    wget "https://github.com/DominicBreuker/pspy/releases/download/v1.2.0/pspy64" -O backup/misc/pspy 
    chmod +x backup/misc/pspy 

    sudo backup/misc/pspy | tee backup/misc/pspy_output_`date +%s`.log > /dev/null &
}

installLINENUM () {
    echo "${GREEN}[+] Configurating services LINENUM '${REPLY}'${RESET}"
    wget "https://raw.githubusercontent.com/rebootuser/LinEnum/master/LinEnum.sh" -O backup/misc/linenum.sh
    chmod +x backup/misc/linenum.sh

    backup/misc/linenum.sh -t | tee backup/misc/linenum_output_`date +%s`.log > /dev/null &
}

# ------------------------------ compileR ------------------------------
compiler_libpam () {
    installpamdependencies
    passwordpolicies
    loginpolicies
    accountpolicies
}

compiler_networking () {
    networking_sysctl_config
    configUFW
    log_current_processes
    monitor_ports
}

compiler_system () {
    system_sysctl_config
    file_permissions
    local answer=""
    echo -n "${CYAN}Disable Ctrl-Alt-Delete? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo 
            disable_ctrl_alt_del
            ;;
        n|N)
            ;;
    esac
}

compiler_services () {
    local SERVICESCONFIGFILE="services.txt"
    echo -e "${RED} Looking through lines on ${RESET}services.txt ${RESET}"
    echo -e "${RED} Configuring ${RESET}services ${RESET}"

    for line in `cat services.txt | sed 's/\r$//'`
    do
        case $line in 
            apache2) 
                configAPACHE2
                ;;
            ssh) 
                configSSH
                ;;
            samba) 
                configSAMBA
                ;;
            vsftpd) 
                configVSFTPD
                ;;
            pure-ftpd) 
                configPUREFTPD
                ;;
            apparmor)
                configAPPARMOR
                ;;
            mysql)
                configMYSQL
                ;;
            mariadb)
                configMARIADB
                ;;
            php)
                configPHP
                ;;
            proftpd)
                configPROFTPD
                ;;
            nullmailer)
                configNULLMAILER
                ;;
            bind9)
                configBIND9
                ;;
            nginx)
                configNGINX
                ;;
            openvpn)
                configOPENVPN
                ;;
            postgresql)
                configPOSTGRESQL
                ;;
            *)
                echo "${RED} No ${RESET}services installed. ${RESET}"
        esac
    done
    installPSPY
    installLINENUM
    configCRON
    configAUDITD
}

echo -e "${RED} Starting ${RESET}Automatic Script 2 ${RESET}"
compiler_libpam
compiler_networking
compiler_system
compiler_services
dpkg --configure -a
apt autoremove -y
echo -e "${RED} Completed ${RESET}Automatic Script 2 ${RESET}"
echo -e "${RED} Completed ${RESET}Automatic System Hardening Script ${RESET}"