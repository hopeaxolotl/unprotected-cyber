#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt

# ------------------------------ compiler_startup functions ------------------------------

chattr_all_config_files () {
    sudo find /etc/ -type f -exec chattr -i {} \;
    sudo find /bin/ -type f -exec chattr -i {} \;
    sudo find /home/ -type f -exec chattr -i {} \;
}

startup_scripts () {
    # Get all init scripts
    echo "${GREEN}[+] Gathering Scripts '${REPLY}'${RESET}"
    ls -la /etc/init/ > backup/services/startup/init_scripts.log
    ls -la /etc/init.d/ >> backup/services/startup/init_scripts.log

    # Get all rc scripts
    ls -la /etc/rc*.d > backup/services/startup/rc_scripts.log

    # Backup and fix rc.local
    local good_rc_local="#!/bin/sh -e\nexit 0"
    sudo cp /etc/rc.local backup/services/startup/rc_local_`date +%s`.bak 
    echo -e '#!/bin/sh -e\nexit 0' | sudo tee /etc/rc.local > /dev/null

    # Find all newly edited files in /etc/
    echo "${GREEN}[*] Files edited recently in backup/misc ${RESET}"
    sudo find /etc/ -type f -newermt 2020-09-01 -ls | tee backup/misc/config_files_edited_since_sept_2020.log > /dev/null
    sudo find /etc/ -type f -mtime -3 -ls | tee backup/misc/config_files_edited_last_3_days.log > /dev/null
}

# ------------------------------ compiler_userfunctions functions ------------------------------

delete_unauthorised_users () {
    echo -e $USERS | sed "s/ /\\n/g" > accusers.txt
    local INVALID=$(diff -n --suppress-common-lines users.txt accusers.txt | cut -d" " -f5-)

    for user in $INVALID
    do 
       	echo "${YELLOW}[!] Removing user: ${user}${RESET}"
       	sudo userdel -r $user
    done
    rm accusers.txt
}

delete_unauthorised_sudoers () {
    local SUDOERS=$(grep "sudo" /etc/group | cut -d":" -f4 | sed "s/,/ /g") 

    echo -e $SUDOERS | sed "s/ /\\n/g" > accsudoers.txt
    local INVALID=$(diff -n --suppress-common-lines sudoers.txt accsudoers.txt | cut -d" " -f5-)
    for sudoer in $INVALID
    do 
        echo "${YELLOW}[!] Removing sudoer: ${sudoer}${RESET}"
        sudo gpasswd -d $sudoer sudo
    done

    rm accsudoers.txt
}

add_new_users () {
    echo "$Type 'exit' to stop."
    echo -n "${CLEARSCREEN}"
    echo "${RED}${BOLD}Type 'exit' to skip/stop.${RESET}"
    while read -r -p "Username to create: " && [[ $REPLY != exit ]]; do 
        echo "${GREEN}[+] Added new user and creating new home directory '${REPLY}'${RESET}"
        sudo useradd -m $REPLY
        sudo passwd -e $REPLY
    done
}

change_users_passwords () {
    # Changes everyone's password to Fus1()n123
    echo "${GREEN}[+] Changing user passwords '${REPLY}'${RESET}"
    for user in $USERS
    do 
    	echo $i:'Fus1()n123' | sudo chpasswd
	    sudo chage -d 0 $i
    sudo chage -I 30 
    done
}

user_misc () {
    echo "${GREEN}[+] Miscellaneous user options '${REPLY}'${RESET}"
    sudo passwd -l root
    sudo usermod -p '!' root
    echo > /etc/securetty
    sudo passwd -d root

    echo "INACTIVE=30" | sudo tee -a /etc/default/useradd > /dev/null
    echo "TMOUT=300"   | sudo tee -a /etc/environment > /dev/null
}

users_check_uid_0 () {
    local UIDS=$(cut /etc/passwd -d: -f1,3 | grep -v root)
    for i in $UIDS
    do 
        local username=$(echo $i | cut -d: -f1)
        local user_uid=$(echo $i | cut -d: -f2)
        if [[ $user_uid -eq "0" ]]
        then 
            echo "${RED}${BOLD}Found a root UID user [${username} : uid ${user_uid}] !${RESET}"
            read -rp $'Press <enter> to continue\n'
        fi
    done
}   

check_shadow_password () { 
    local SHADOW=$(sudo cat /etc/shadow)
    for line in $SHADOW
    do 
        local password_hash=$(echo $line | cut -d: -f2)
        local account=$(echo $line | cut -d: -f1)
        if [[ -z $password_hash  ]]
        then 
            echo "${RED}${BOLD}Empty password${RESET}${RED} for account ${RED}${BOLD}${account}${RESET}${RED} found in ${RED}/etc/shadow!${RESET}"
            read -rp $'Press <enter> to continue\n'
        fi
    done
}

# ------------------------------ compiler_apt functions ------------------------------

install_necessary_packages () {
    echo "${GREEN}[+] Installing packages '${REPLY}'${RESET}"
    sudo $APT install -y ufw
    sudo $APT install -y tmux
    sudo $APT install -y vim
    sudo $APT install -y unhide
    sudo $APT install -y auditd
    sudo $APT install -y psad
    sudo $APT install -y fail2ban
    sudo $APT install -y aide
    sudo $APT install -y tcpd
    sudo $APT install -y libpam-cracklib
    sudo $APT install -y tree
}

enumerate_packages () {
    echo "${GREEN}[+] Enumerating packages '${REPLY}'${RESET}"
    sudo apt list --installed > backup/apt/apt_list_installed_packages.log
    sudo dpkg -l > backup/apt/dpkg_installed_packages.log

    sudo apt-mark showmanual > backup/apt/manually_installed_packages.log

}

remove_malware () {

    echo "${RED}Please make sure you are 100% sure that there is no critical services in this before running!!${RESET}"
    declare -a arr=(john, abc, sqlmap, aria2
                    aquisition, bitcomet, bitlet, bitspirit
                    endless-sky, zenmap, minetest, minetest-server
                    armitage, crack, knocker, aircrack-ng
                    airbase-ng, hydra, freeciv
                    wireshark, tshark
                    hydra-gtk, netcat, netcat-traditional, netcat-openbsd
                    netcat-ubuntu, netcat-minimal, qbittorrent, ctorrent
                    ktorrent, rtorrent, deluge, transmission-common
                    transmission-bittorrent-client, tixati, frostwise, vuse
                    irssi, transmission-gtk, utorrent, kismet
                    medusa, telnet, exim4, telnetd
                    bind9, crunch, tcpdump, tomcat
                    tomcat6, vncserver, tightvnc, tightvnc-common
                    tightvncserver, vnc4server, nmdb, dhclient
                    telnet-server, ophcrack, cryptcat, cups
                    cupsd, tcpspray, ettercap
                    wesnoth, snort, pryit
		    weplab, wireshark, nikto, lcrack
                    postfix, snmp, icmp, dovecot
                    pop3, p0f, dsniff, hunt, zsnes
                    ember, nbtscan, rsync, freeciv-client-extras
                    freeciv-data, freeciv-server, freeciv-client-gtk, tor, goldeneye
                    )

    for i in "${arr[@]}"
    do
        sudo $APT purge -y --force-yes $i
    done
}

enable_automatic_updates () {
    echo "${GREEN}[+] Unattended upgrades '${REPLY}'${RESET}"
    sudo $APT install -y unattended-upgrades apt-listchanges

    echo "APT::Get::AllowUnauthenticated \"false\";" | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null
    echo "Unattended-Upgrade::Remove-Unused-Dependencies \"true\";" | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null
    echo "Unattended-Upgrade::Remove-Unused-Kernel-Packages \"true\";" | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null

    echo 'APT::Periodic::Update-Package-Lists "1";' | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null
    echo 'APT::Periodic::Download-Upgradeable-Packages "1";' | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null
    echo 'APT::Periodic::Unattended-Upgrade "1";' | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null
    echo 'APT::Periodic::AutocleanInterval "7";' | sudo tee -a /etc/apt/apt.conf.d/10periodic > /dev/null

    echo 'APT::Periodic::Update-Package-Lists "1";' | sudo tee /etc/apt/apt.conf.d/20auto-upgrades > /dev/null
    echo 'APT::Periodic::Download-Upgradeable-Packages "1";' | sudo tee -a /etc/apt/apt.conf.d/20auto-upgrades > /dev/null
    echo 'APT::Periodic::Unattended-Upgrade "1";' | sudo tee -a /etc/apt/apt.conf.d/20auto-upgrades > /dev/null
    echo 'APT::Periodic::AutocleanInterval "7";' | sudo tee -a /etc/apt/apt.conf.d/20auto-upgrades > /dev/null

    sudo systemctl unmask snapd.service
    sudo snap set system refresh.metered=null
    sudo snap unset system refresh.hold
    sudo snap set system refresh.timer=00:00~24:00/4
    snap refresh --time
}

fix_sources_list () { 
    echo "${GREEN}[+] Fixing sources list '${REPLY}'${RESET}"
    local ubuntu_sources="
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME main restricted\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates main restricted\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME universe\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates universe\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME multiverse\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates multiverse\n
deb http://us.archive.ubuntu.com/ubuntu/ CHANGEME-backports main restricted universe multiverse\n
deb http://security.ubuntu.com/ubuntu CHANGEME-security main restricted\n
deb http://security.ubuntu.com/ubuntu CHANGEME-security universe\n
deb http://security.ubuntu.com/ubuntu CHANGEME-security multiverse\n

deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME main restricted\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates main restricted\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME universe\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates universe\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME multiverse\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME-updates multiverse\n
deb-src http://us.archive.ubuntu.com/ubuntu/ CHANGEME-backports main restricted universe multiverse\n
deb-src http://security.ubuntu.com/ubuntu CHANGEME-security main restricted\n
deb-src http://security.ubuntu.com/ubuntu CHANGEME-security universe\n
deb-src http://security.ubuntu.com/ubuntu CHANGEME-security multiverse\n
"

    local debian_sources="
deb http://deb.debian.org/debian CHANGEME main\n
deb-src http://deb.debian.org/debian CHANGEME main\n
deb http://deb.debian.org/debian-security/ CHANGEME/updates main\n
deb-src http://deb.debian.org/debian-security/ CHANGEME/updates main\n
deb http://deb.debian.org/debian CHANGEME-updates main\n
deb-src http://deb.debian.org/debian CHANGEME-updates main\n
"

    sudo cp -r /etc/apt/sources.list* backup/apt/ 
    sudo rm -f /etc/apt/sources.list 
    case $DISTRO in 
        Debian)
            echo -e $debian_sources | sed "s/ deb/deb/g; s/CHANGEME/${CODENAME}/g" | sudo tee /etc/apt/sources.list > /dev/null
            ;;
        Ubuntu)
            echo -e $ubuntu_sources | sed "s/ deb/deb/g; s/CHANGEME/${CODENAME}/g" | sudo tee /etc/apt/sources.list > /dev/null
            ;;
        *)  
            sudo cp backup/apt/sources.list /etc/apt/sources.list
            echo -e "${RED}${BOLD}Distro not recognised!\nExiting#${RESET}"
            exit 1
            ;;

    esac
}

config_tmux () {
    echo "${GREEN}[+] Configurating TMUX '${REPLY}'${RESET}"
    echo "set -g lock-after-time 900" | sudo tee -a /etc/tmux.conf > /dev/null
    echo "set -g lock-command vlock"  | sudo tee -a /etc/tmux.conf > /dev/null
    echo "[ -n '$PS1' -a -z '$TMUX' ] && exec tmux" | sudo tee -a /etc/bashrc > /dev/null

}

install_and_run_rngtools () {
    echo "${GREEN}[+] Installing/running RNGTools '${REPLY}'${RESET}"
    sudo apt -y install rng-tools && sudo systemctl start rng-tools && sudo systemctl enable rng-tools
}

update () {
    echo "${GREEN}[+] Updating '${REPLY}'${RESET}"
    sudo snap refresh
    sudo $APT -y update && sudo $APT -y upgrade
}


configENUM () {
    echo "${GREEN}[+] Disabling a bunch of stuff not needed '${REPLY}'${RESET}"
        
    $APT purge -y xserver-xorg*
    $APT purge -y openbsd-inetd
    $APT purge -y ldap-utils 
    $APT purge -y nis
    $APT purge -y talk
    $APT purge -y telnet # Scored
}

# ------------------------------ Compiling the compiler's compiler Compile Compiler ------------------------------

compiler_startup() {
    echo " ${GREEN} Unprotected Cyber System Hardening Script ${RESET}" 
    echo "Thanks to the creators of I am Root Script and Gl0ckrain"
	sleep 1
    echo "${YELLOW} This version of the script is highly experimental ${RESET}"
	echo "${RED}*STOP!* Forensic questions must be completed before as this script will break and delete certain aspects of the machine. ${RESET}"
	echo Press enter to continue when all these things have been done:
	read -p "" prompt
    clear
    nano services.txt
    nano users.txt
    nano sudoers.txt
	echo "${GREEN} Please now copy all allowed users to users.txt, all sudoers to sudoers.txt and all critical services to services.txt, press enter to continue ${RESET}"
	read -p "" prompt
    clear
	sleep 1
    echo "${GREEN} Making backup directories {$RESET}"

    mkdir -p backup/users
    mkdir -p backup/pam
    mkdir -p backup/apt
    
    mkdir -p backup/services
    mkdir -p backup/services/crons
    mkdir -p backup/services/startup

    mkdir -p backup/networking
    mkdir -p backup/system
    mkdir -p backup/malware

    mkdir -p backup/misc
    mkdir -p backup/misc/media

    echo "${GREEN}[*] Giving permissions to necessary files ... ${RESET}"
    chattr_all_config_files

    clear
    sleep 2
    startup_scripts

}

compiler_userfunctions () {
    local answer=""
    echo -n "${CYAN}Delete unauthorised users? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo 
            echo "${CYAN}Press <enter> after adding ${BOLD}./users.txt${RESET}"
            read -r
            delete_unauthorised_users
            ;;
        n|N)
            ;; # Do
    esac

    echo -n "${CYAN}Delete unauthorised sudoers? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            echo
            echo "${CYAN}Press <enter> after adding ${BOLD}./sudoers.txt${RESET}"
            read -r
            delete_unauthorised_sudoers
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo -n "${CYAN}Add users? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            add_new_users 
            ;;
        n|N)
            ;; # Do nothing
    esac

    echo -n "${CYAN}Change all users passwords? [${GREEN}y${CYAN}|${RED}N${CYAN}] : ${RESET}"
    read -rp "" answer
    case $answer in 
        y|Y)
            change_users_passwords 
            ;;
        n|N)
            ;; # Do nothing
    esac
    
    users_check_uid_0
    check_shadow_password
    user_misc
}

compiler_apt () {
    fix_sources_list
    sudo $APT update
    enable_automatic_updates
    remove_malware
    install_necessary_packages
    update
    configENUM
    enumerate_packages
    config_tmux
    install_and_run_rngtools
}

echo -e "${RED} Starting Automatic Script 1 ${RESET}"
compiler_startup
compiler_userfunctions
compiler_apt
echo -e "${RED} Completed Automatic Script 1 ${RESET}"
echo -e "${RED} Restart System to proceed further and complete updates ${RESET}"
