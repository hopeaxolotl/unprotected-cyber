#!/usr/bin/env python3
import sys
import subprocess
import os
from PyQt5.QtWidgets import (
    QApplication, QLabel, QMainWindow, QPushButton, QVBoxLayout, QWidget, QTextEdit, QMessageBox, QHBoxLayout, QStackedLayout
)
from PyQt5.QtGui import QPixmap, QFont, QFontDatabase
from PyQt5.QtCore import QTimer, Qt

class TextDisplayWidget(QWidget):
    def __init__(self):
        super().__init__()

        self.text_edit = QTextEdit()
        self.text_edit.setReadOnly(True)
        self.text_edit.setStyleSheet("background-color: black; color: green; padding: 20px")
        self.text_edit.setFont(QFont("Courier New", 12))

        self.text_edit.setAlignment(Qt.AlignLeft)

    def update_text(self):
        if self.current_line < len(self.lines):
            self.text_edit.append(self.lines[self.current_line])
            self.current_line += 1
        else:
            self.timer.stop()

class AutoWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.load_font()

        self.setWindowTitle('Unprotected Cyberscript')
        self.setFixedSize(1366, 768)

        self.text_widget = TextDisplayWidget()
        self.setCentralWidget(self.text_widget)

        self.switch_timer = QTimer(self)
        self.switch_timer.timeout.connect(self.show_menu)
        self.switch_timer.setSingleShot(True)
        self.switch_timer.start(0)

    def load_font(self):
        font_path = "fonts/HelveticaNeueHeavy.otf"
        font_id = QFontDatabase.addApplicationFont(font_path)
        
        if font_id != -1:
            font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
            print(f"Font loaded: {font_family}")
        else:
            print("Failed to load font. Please check the font path and file.")

    def show_menu(self):
        menu_widget = QWidget()

        background_label = QLabel(menu_widget)
        background_label.setPixmap(QPixmap("backgrounds/menuauto.png")) 
        background_label.setScaledContents(True)
        background_label.setGeometry(0, 0, self.width(), self.height()) 

        vbox_layout = QVBoxLayout()
        vbox_layout.setSpacing(20)
        vbox_layout.setContentsMargins(0, 0, 0, 200)
        vbox_layout.setAlignment(Qt.AlignLeft)

        button_names = [
            "           Automatic Script 1 - User Admin, Malware/Updates                                            ",
            "           Automatic Script 2 - PAM, Networking/Kernel (SystemD), Misc/Services            ",
            "        Autoremove Unnecessary Items                                                                        ",
            "           Download and Run Webmin                                                                                  ",
            "      Download and Run Lynis                                                                                 ",
            "               Back                                                                                                                         "
        ]

        for name in button_names:
            button = QPushButton(name)
            button.clicked.connect(lambda checked, name=name: self.on_button_click(name))
            button.setFont(QFont("Helvetica Neue", 16))
            button.setStyleSheet("""
                QPushButton {
                    color: gray;
                    background: none;
                    border: none;
                    padding: 0px;
                }
                QPushButton:hover {
                    color: #f0a001; 
                }
            """)
            vbox_layout.addWidget(button)

        overlay_widget = QWidget(menu_widget)
        overlay_widget.setLayout(vbox_layout)
        overlay_widget.setGeometry(0, 0, self.width(), self.height())
        overlay_widget.setStyleSheet("background: transparent;")

        self.setCentralWidget(menu_widget)


    def on_button_click(self, button_name):
        if button_name == "           Automatic Script 1 - User Admin, Malware/Updates                                            ":
            self.run_script("auto/auto1.sh")
        elif button_name == "           Automatic Script 2 - PAM, Networking/Kernel (SystemD), Misc/Services            ":
            self.run_script("auto/auto2.sh")
        elif button_name == "        Autoremove Unnecessary Items                                                                        ":
            self.run_script("opts/autoremove.sh")
        elif button_name == "           Download and Run Webmin                                                                                  ":
            self.run_script("opts/webmin.sh")
        elif button_name == "      Download and Run Lynis                                                                                 ":
            self.run_script("opts/lynis.sh")
        elif button_name == "               Back                                                                                                                         ":
            self.run_script("back.sh")

    def run_script(self, script_name):
        try:
            subprocess.run(["./" + script_name], check=True, shell=True)
        except subprocess.CalledProcessError as e:
            QMessageBox.warning(self, "Error", f"Failed to run {script_name}: {e}")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"An unexpected error occurred: {e}")


def load_automatic_content(main_window):
    auto_window = AutoWindow()
    main_window.setCentralWidget(auto_window)