#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ gnome functions ------------------------------
configGNOME () {
    echo "${GREEN}[*] Configuring GNOME ... ${RESET}"

    sudo touch /etc/dconf/db/local.d/00-screensaver 
    echo "[org/gnome/desktop/session]" | sudo tee -a /etc/dconf/db/local.d/00-screensaver
    echo "idle-delay=uint32 180" | sudo tee -a /etc/dconf/db/local.d/00-screensaver
    echo "[org/gnome/desktop/screensaver]" | sudo tee -a /etc/dconf/db/local.d/00-screensaver
    echo "lock-enabled=true" | sudo tee -a /etc/dconf/db/local.d/00-screensaver
    echo "lock-delay=uint32 300" | sudo tee -a /etc/dconf/db/local.d/00-screensaver

    sudo touch /etc/dconf/db/local.d/locks/screensaver
    echo "/org/gnome/desktop/session/idle-delay" | sudo tee -a /etc/dconf/db/local.d/locks/screensaver
    echo "/org/gnome/desktop/screensaver/lock-enabled" | sudo tee -a /etc/dconf/db/local.d/locks/screensaver
    echo "/org/gnome/desktop/screensaver/lock-delay" | sudo tee -a /etc/dconf/db/local.d/locks/screensaver

    sudo touch /etc/dconf/db/local.d/locks/session
    echo "/org/gnome/desktop/screensaver/lock-enabled" | sudo tee -a /etc/dconf/db/local.d/locks/session
    echo "/org/gnome/desktop/session/idle-delay" | sudo tee -a /etc/dconf/db/local.d/locks/session

    sudo gsettings set org.gnome.desktop.screensaver lock-enabled true && sudo dconf update

    echo "[org/gnome/settings-daemon/plugins/media-keys]" | sudo tee -a /etc/dconf/db/local.d00-disable-CAD
    echo "logout=''" | sudo tee -a /etc/dconf/db/local.d00-disable-CAD
    dconf update

    echo "banner-message-enable=true" | sudo tee -a /etc/gdm3/greeter.dconf-defaults
    echo "banner-message-text='Fuck zsh'" | sudo tee -a /etc/gdm3/greeter.dconf-defaults
    echo "disable-user-list=true" | sudo tee -a /etc/gdm3/greeter.dconf-defaults

    sudo dconf update

    echo "AutomaticLoginEnable=False" | sudo tee -a /etc/gdm3/custom.conf
}

configGNOME