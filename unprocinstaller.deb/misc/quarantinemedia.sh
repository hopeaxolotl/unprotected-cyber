#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ quarnatinemedia ------------------------------
delete_media () {
    echo "${GREEN}[*] Quarantining media files ... ${RESET}"
    sudo find / -name '*.mp3' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.mov' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.mp4' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.avi' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.mpg' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.mpeg' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.flac' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.m4a' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.flv' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find / -name '*.ogg' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find /home -name '*.gif' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find /home -name '*.png' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find /home -name '*.jpg' -type f -exec mv {} backup/misc/media \; 2> /dev/null
    sudo find /home -name '*.jpeg' -type f -exec mv {} backup/misc/media \; 2> /dev/null
}

delete_media