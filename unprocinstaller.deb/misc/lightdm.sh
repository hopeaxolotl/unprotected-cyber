#!/bin/bash
BLACK=$(tput setaf 0)
WHITE2=$(tput setaf 7)
RED=$(tput setaf 1)
GREEN=$(tput setaf 2)
YELLOW=$(tput setaf 3)
MAGENTA=$(tput setaf 5)
CYAN=$(tput setaf 6)
RESET=$(tput sgr 0)
USERS=$(grep -E "/bin/.*sh" /etc/passwd | grep -v -e root -e `whoami` -e speech-dispatcher | cut -d":" -f1)
DISTRO=$(lsb_release -i | cut -d: -f2 | sed "s/\\t//g")
CODENAME=$(lsb_release -c | cut -d: -f2 | sed "s/\\t//g")
CCHOST=$(hostname)
CCUSER=$(whoami)
APT=apt
# ------------------------------ lightdm configurations ------------------------------
configLDM () {
    echo "${GREEN}[*] Configuring LightDM ... ${RESET}"

    echo "[Seat:*]" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "autologin-user=`whoami`" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "greeter-hide-users=true" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "greeter-show-manual-login=true" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "greeter-show-remote-login=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "allow-guest=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "autologin-guest=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "greeter-allow-guest=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "allow-user-switching=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "AutomaticLoginEnable=false" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "xserver-allow-tcp=false" | sudo tee -a /etc/lightdm/lightdm.conf

    echo "[XDMCPServer]" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "enabled=false" | sudo tee -a /etc/lightdm/lightdm.conf

    echo "[VNCServer]" | sudo tee -a /etc/lightdm/lightdm.conf
    echo "enabled=false" | sudo tee -a /etc/lightdm/lightdm.conf

    echo "[UserList]" | sudo tee -a /etc/lightdm/users.conf
    echo "minimum-uid=500" | sudo tee -a /etc/lightdm/users.conf
    echo "hidden-users=nobody nobody4 noaccess" | sudo tee -a /etc/lightdm/users.conf
    echo "hidden-shells=/bin/false /usr/sbin/nologin" | sudo tee -a /etc/lightdm/users.conf

    service restart lightdm
}

configLDM