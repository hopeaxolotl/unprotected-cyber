#!/bin/bash
echo -e "Unprotected Cyber General Documentation"
echo -e " Startup Instructions"
echo -e " Not applicable at moment, check back later!"
