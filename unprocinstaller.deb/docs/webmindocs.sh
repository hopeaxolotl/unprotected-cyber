#!/bin/bash
echo -e "Unprotected Cyber General Documentation"

echo -e "Functionalities:
cron jobs: system > scheduled cron jobs
pam: system > pam authentication
systemd (running services): system > bootup and shutdown
change passwords: system > change passwords
filesystems: system > disk and network filesystems
backup: system > filesystem backup
log files: system > log file rotation
mime: system > MIME type programs
ps -aux:  system > running processes
update gui: system > software package updates
install dpkg gui: system > software packages
users and groups: system > users & groups
terminal: tools > command shell
terminal: tools > terminal
custom commands (for fun): tools > custom commands
http tunnel: tools > http tunnel
view/install perl modules: tools > perl modules
add protection for a web directory: tools > protected web directories
server status: tools > system and server status
github download tool maybe: tools > upload and download
monitoring bandwith using iptables and syslog: networking > bandwidth monitoring
iptables ipv4 firewall: networking > linux firewall
iptables ipv6 firewall: networking > linux ipv6 firewall
network config (netplan): networking > network configuration
NIS Client: networking > nis client and server
vpn tunnelling: networking > pptp vpn client
tcp wrappers: networking > tcp wrappers
system time/ time server: hardware > system time

Cluster:
Change passwords
copy files
cron jobs
shell commands
software packages
usermin servers
user groups
webmin servers

Services modules:
ADSL Client
apache web server
bacula backup system
bind dns server
dhcp server
disk quotas
dovecot imap/pop3 server
fail2ban intrusion detector
fetchmail mail retrieval
firewalld
heartbeat monitor
idmapd daemon
ipsec vpn configuration
iscsi client
iscsi server
iscsi target
iscsi tgtd
kerberos5
ldap client
ldap server
ldap users and groups
linux raid
logical volume management
mysql database server
network services
network services and protocols
nfs exports
openslp server
php configuration
postfix mail server
postgresql database server
ppp dialin server
ppp dialup server
pptp vpn server
procmail mail filter
proftpd server
qmail mail server
samba windows file sharing
scheduled commands
sendmail mail server
shorewall firewall
shorewall6 firewall
smart drive status
spamassassin mail filter
squid proxy server
squid report generator
ssh server
ssl tunnels
system logs ng
usermin configuration
webalizer logfile analysis"
